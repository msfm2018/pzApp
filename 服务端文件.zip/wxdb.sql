/*
 Navicat Premium Dump SQL

 Source Server         : 小程序
 Source Server Type    : MySQL
 Source Server Version : 90200 (9.2.0)
 Source Host           : localhost:3306
 Source Schema         : wxdb

 Target Server Type    : MySQL
 Target Server Version : 90200 (9.2.0)
 File Encoding         : 65001

 Date: 23/04/2025 20:10:33
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for application_table
-- ----------------------------
DROP TABLE IF EXISTS `application_table`;
CREATE TABLE `application_table`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `orderid` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `phone` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `dt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `isprocessed` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT '0' COMMENT '是否处理',
  `processedtime` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '处理时间',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `orderid`(`orderid` ASC) USING BTREE,
  INDEX `phone`(`phone` ASC) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 6 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of application_table
-- ----------------------------
INSERT INTO `application_table` VALUES (3, '20231019960810051', '13240793600', '2023-10-19 13:25:40', '2', NULL);
INSERT INTO `application_table` VALUES (4, '20231019107210041', '13240793600', '2023-10-19 14:36:04', '2', NULL);
INSERT INTO `application_table` VALUES (5, '20231020711610041', '13240793600', '2023-10-20 10:35:51', '2', NULL);

-- ----------------------------
-- Table structure for ask
-- ----------------------------
DROP TABLE IF EXISTS `ask`;
CREATE TABLE `ask`  (
  `phone` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `show` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '登录主界面显示控制'
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of ask
-- ----------------------------
INSERT INTO `ask` VALUES ('10086', 'true');

-- ----------------------------
-- Table structure for assignment
-- ----------------------------
DROP TABLE IF EXISTS `assignment`;
CREATE TABLE `assignment`  (
  `AssignmentID` int NOT NULL AUTO_INCREMENT COMMENT '派单表',
  `phone` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `orderid` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `AssignmentTime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `state` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT '0',
  PRIMARY KEY (`AssignmentID`) USING BTREE,
  INDEX `phone`(`phone` ASC) USING BTREE,
  INDEX `orderid`(`orderid` ASC) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 7 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of assignment
-- ----------------------------
INSERT INTO `assignment` VALUES (4, '13240793600', '20231019960810051', '2023-10-19 13:29:25', '2');
INSERT INTO `assignment` VALUES (5, '13240793600', '20231019107210041', '2023-10-19 14:36:55', '2');
INSERT INTO `assignment` VALUES (6, '13240793600', '20231020711610041', '2023-10-20 10:36:07', '2');

-- ----------------------------
-- Table structure for companions
-- ----------------------------
DROP TABLE IF EXISTS `companions`;
CREATE TABLE `companions`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `phone` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `address` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `cardid` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `gender` varchar(25) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `qualification` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '陪诊员的资格或证书。',
  `experience_years` varchar(11) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '陪诊员的工作经验年限。',
  `specialties` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL COMMENT '陪诊员的专长领域，使用 TEXT 数据类型以容纳较长的文本。',
  `availability` tinyint(1) NULL DEFAULT 0 COMMENT '陪诊员的可用性，通常使用布尔值表示。',
  `profile_text` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL COMMENT '陪诊员的个人简介或描述，使用 TEXT 数据类型',
  `profile_image_url` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '陪诊员的头像或图片 URL',
  `pwd` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `vc` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '验证码',
  `age` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`, `phone`) USING BTREE,
  INDEX `phone`(`phone` ASC) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 21 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of companions
-- ----------------------------
INSERT INTO `companions` VALUES (17, '小马', '13240793600', '北京大兴', '010503192102111310', '', '无', '2', '陪诊', 1, '你看吧', NULL, '1', NULL, NULL);
INSERT INTO `companions` VALUES (18, '测试', '18900000000', '海淀', '010503192102111310', '0', '无', '24', '无', 0, '无', NULL, '1', NULL, '32');
INSERT INTO `companions` VALUES (19, 'zsm', '13682821000', '广州', '015224288010233018', '0', '21322', '3', '无', 0, '无', NULL, '1234567890', NULL, '23');
INSERT INTO `companions` VALUES (20, '洛与霞', '13682821000', '广东省广州市白云区', '010224206602140024', '0', '46895', '5', '医疗陪诊', 0, '具备的一些专业技能：熟悉医院的运作流程和医疗服务体系；掌握基本的医疗知识和急救技能；熟悉使用医疗软件和设备；具备同理心，能够理解患者的情绪和需求。本人将用专业和关爱，为医患的健康之路保驾护航！本人连续三次被医院评为“优秀陪诊员”，能在就医过程提供优质服务，提高患者的就医体验。', NULL, '13681853', NULL, '20');

-- ----------------------------
-- Table structure for evaluation
-- ----------------------------
DROP TABLE IF EXISTS `evaluation`;
CREATE TABLE `evaluation`  (
  `EvaluationID` int NOT NULL AUTO_INCREMENT,
  `AssignmentID` int NULL DEFAULT NULL,
  `Rating` int NULL DEFAULT NULL,
  `Comments` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL,
  `EvaluationTime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`EvaluationID`) USING BTREE,
  INDEX `AssignmentID`(`AssignmentID` ASC) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of evaluation
-- ----------------------------

-- ----------------------------
-- Table structure for service_info
-- ----------------------------
DROP TABLE IF EXISTS `service_info`;
CREATE TABLE `service_info`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `icon` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL,
  `url` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `price` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `n1` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `n2` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `n3` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 5 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of service_info
-- ----------------------------
INSERT INTO `service_info` VALUES (1, '挂号服务', 'http://127.0.0.1/allimg/pc.png', '诊前约号服务内容', '      此挂号服务（不包含医生咨询费用）仅为用户提供挂号协助，因各大医院就诊患者数量很大，并不承诺可以在用户要求时间内成功挂号，出诊信息以医院官网信息为准。如对挂号流程有疑问，或需要帮助进行挂号，请提前联系客服咨询。承诺7天内为患者进行挂号的，如未成功为患者办理挂号服务，我方将全额退费。任何一方不得单方面解除违约合同，如用户乙方单方面解除委托合同，所支付的费用不予退还。另外，由于医院方面原因，如医生停诊等不可抗拒因素导致无法按时就诊的，因前期已消耗时间、人力成本，所支付费用不予退还。', 'http://127.0.0.1/allimg/pc_guahao.jpg', '100', '代挂号', '超值价:100.00元/次', '省时省力、方便性、避免纸质流程、更好的就医体验、帮助特殊人群');
INSERT INTO `service_info` VALUES (2, '代办问诊', 'http://127.0.0.1/allimg/car.png', '代办问诊服务内容', '      协助医学诊断：代办问诊服务可以协助患者收集病史信息和症状描述，帮助医生更好地理解患者的情况。\r\n安排医疗咨询时间：服务提供者会帮助患者或委托人安排医疗咨询的具体时间和地点，以确保患者能够及时得到医疗建议。\r\n提供医疗建议和解释：代办问诊服务可能还包括协助解释医生的诊断和治疗建议，以帮助患者更好地理解医疗情况。\r\n适用人群包括：\r\n有语言障碍的患者：对于那些不懂医生的语言或有沟通障碍的患者，代办问诊可以提供翻译和沟通支持。\r\n外地患者：外地患者可能需要协助安排医疗咨询，以便在陌生城市中获得医疗服务。\r\n有特殊需求的患者：如老年人、残障人士、单身家庭、不懂医疗程序的患者等可能需要额外的支持和协助。\r\n忙碌的职业人士：那些没有足够时间或机会自己处理医疗咨询的职业人士可能会受益于代办问诊服务。', 'http://127.0.0.1/allimg/car_wenzhen.png', '100', '代办问诊', '超值价:100.00元/次', '便捷性和时间节省、提供专业支持、协助安排医疗时间、支持特殊人群、减轻患者负担');
INSERT INTO `service_info` VALUES (3, '代取送达', 'http://127.0.0.1/allimg/flyer.png', '取送结果服务内容', '      适用于无法亲自到院送/取结果与无法亲自到医院取药的用户，下单即可快递结果到家（不含运费），服务仅当天有效', 'http://127.0.0.1/allimg/flyer_daiqu.jpg', '200', '代取服务', '超值价:200.00元/次', '为他人代办医院结果或者药物的领取，并在完成后快递寄出 节省时间 减轻患者负担 提供便捷性 帮助特殊人群');
INSERT INTO `service_info` VALUES (4, '全程陪诊', 'http://127.0.0.1/allimg/bag.png', '全程陪诊服务内容', '      交通和导航：提供交通支持，协助患者前往医疗机构，提供导航帮助。\r\n翻译和沟通：提供语言翻译服务，协助患者与医生和医护人员进行有效沟通。\r\n陪同就诊：陪同患者在医生面前，提供支持，记录医疗建议和药物处方。\r\n医疗报告和结果：协助患者收取医疗报告、检查结果和药物，确保及时处理。\r\n情感支持：提供情感支持，安慰患者，减轻焦虑和不安。\r\n      协助支付和报销：帮助患者处理医疗费用、医保报销和保险索赔。适用于但不限于老年人、单身人群、语言障碍人士、单亲家庭、外地患者（无独立行为的暂无法接单）', 'http://127.0.0.1/allimg/car_peizhen.jpg', '500', '全程陪诊', '超值价:500.00元/次', '陪诊就医、专业保障、省事省心 （陪诊首选 4小时陪诊服务上午或下午)');

-- ----------------------------
-- Table structure for service_order
-- ----------------------------
DROP TABLE IF EXISTS `service_order`;
CREATE TABLE `service_order`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `phone` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `hospital` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `department` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `orderdate` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `gender` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `timestamp` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `other` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `userid` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `order_state` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT '0' COMMENT '0=派单中 1=已派单',
  `orderid` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `serviceid` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `delflag` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT '0' COMMENT '0 正常 1代表删除',
  PRIMARY KEY (`id`, `orderid`) USING BTREE,
  UNIQUE INDEX `orderid`(`orderid` ASC) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 38 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of service_order
-- ----------------------------
INSERT INTO `service_order` VALUES (34, '18210070000', '刘先生', '北京积水潭医院', '脊柱', '2023-10-17 10:17', '女', '2023-10-19 08:43:47', '', '10051', '2', '20231019960810051', '1', '0');
INSERT INTO `service_order` VALUES (35, '13200000000', '张先生', '北京协和医院', '骨科', '2023-10-17 10:17', '女', '2023-10-19 14:31:59', '', '10041', '2', '20231019107210041', '1', '0');
INSERT INTO `service_order` VALUES (36, '13600000000', '王先生', '北京天坛医院', '内科', '2023-10-22 10:17', '女', '2023-10-20 10:34:42', '无', '10041', '2', '20231020711610041', '1', '0');
INSERT INTO `service_order` VALUES (37, '13240999000', '张先生', '北京大学人民医院', '外科', '2024-04-27 12:50', '未定义', '2024-04-25 12:48:37', '无', '10041', '2', '2024425373110041', '1', '0');

-- ----------------------------
-- Table structure for swiper
-- ----------------------------
DROP TABLE IF EXISTS `swiper`;
CREATE TABLE `swiper`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `picUrl` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `tip` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `idx`(`id` ASC) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 5 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of swiper
-- ----------------------------
INSERT INTO `swiper` VALUES (1, 'http://127.0.0.1/swiper/1.jpg', '关怀', '约号');
INSERT INTO `swiper` VALUES (2, 'http://127.0.0.1/swiper/2.jpg', '好友', '问诊');
INSERT INTO `swiper` VALUES (3, 'http://127.0.0.1/swiper/3.jpeg', '老友', '送取结果');
INSERT INTO `swiper` VALUES (4, 'http://127.0.0.1/swiper/4.jpg', '陪诊', '取药');

-- ----------------------------
-- Table structure for unique_numbers
-- ----------------------------
DROP TABLE IF EXISTS `unique_numbers`;
CREATE TABLE `unique_numbers`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `number` int NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `unique_index_name`(`id` ASC) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 102 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of unique_numbers
-- ----------------------------
INSERT INTO `unique_numbers` VALUES (33, 1);
INSERT INTO `unique_numbers` VALUES (34, 1);
INSERT INTO `unique_numbers` VALUES (35, 1);
INSERT INTO `unique_numbers` VALUES (36, 1);
INSERT INTO `unique_numbers` VALUES (37, 1);
INSERT INTO `unique_numbers` VALUES (38, 1);
INSERT INTO `unique_numbers` VALUES (39, 1);
INSERT INTO `unique_numbers` VALUES (40, 1);
INSERT INTO `unique_numbers` VALUES (41, 1);
INSERT INTO `unique_numbers` VALUES (42, 1);
INSERT INTO `unique_numbers` VALUES (43, 1);
INSERT INTO `unique_numbers` VALUES (44, 1);
INSERT INTO `unique_numbers` VALUES (45, 1);
INSERT INTO `unique_numbers` VALUES (46, 1);
INSERT INTO `unique_numbers` VALUES (47, 1);
INSERT INTO `unique_numbers` VALUES (48, 1);
INSERT INTO `unique_numbers` VALUES (49, 1);
INSERT INTO `unique_numbers` VALUES (50, 1);
INSERT INTO `unique_numbers` VALUES (51, 1);
INSERT INTO `unique_numbers` VALUES (52, 1);
INSERT INTO `unique_numbers` VALUES (53, 1);
INSERT INTO `unique_numbers` VALUES (54, 1);
INSERT INTO `unique_numbers` VALUES (55, 1);
INSERT INTO `unique_numbers` VALUES (56, 1);
INSERT INTO `unique_numbers` VALUES (57, 1);
INSERT INTO `unique_numbers` VALUES (58, 1);
INSERT INTO `unique_numbers` VALUES (59, 1);
INSERT INTO `unique_numbers` VALUES (60, 1);
INSERT INTO `unique_numbers` VALUES (61, 1);
INSERT INTO `unique_numbers` VALUES (62, 1);
INSERT INTO `unique_numbers` VALUES (63, 1);
INSERT INTO `unique_numbers` VALUES (64, 1);
INSERT INTO `unique_numbers` VALUES (65, 1);
INSERT INTO `unique_numbers` VALUES (66, 1);
INSERT INTO `unique_numbers` VALUES (67, 1);
INSERT INTO `unique_numbers` VALUES (68, 1);
INSERT INTO `unique_numbers` VALUES (69, 1);
INSERT INTO `unique_numbers` VALUES (70, 1);
INSERT INTO `unique_numbers` VALUES (71, 1);
INSERT INTO `unique_numbers` VALUES (72, 1);
INSERT INTO `unique_numbers` VALUES (73, 1);
INSERT INTO `unique_numbers` VALUES (74, 1);
INSERT INTO `unique_numbers` VALUES (75, 1);
INSERT INTO `unique_numbers` VALUES (76, 1);
INSERT INTO `unique_numbers` VALUES (77, 1);
INSERT INTO `unique_numbers` VALUES (78, 1);
INSERT INTO `unique_numbers` VALUES (79, 1);
INSERT INTO `unique_numbers` VALUES (80, 1);
INSERT INTO `unique_numbers` VALUES (81, 1);
INSERT INTO `unique_numbers` VALUES (82, 1);
INSERT INTO `unique_numbers` VALUES (83, 1);
INSERT INTO `unique_numbers` VALUES (84, 1);
INSERT INTO `unique_numbers` VALUES (85, 1);
INSERT INTO `unique_numbers` VALUES (86, 1);
INSERT INTO `unique_numbers` VALUES (87, 1);
INSERT INTO `unique_numbers` VALUES (88, 1);
INSERT INTO `unique_numbers` VALUES (89, 1);
INSERT INTO `unique_numbers` VALUES (90, 1);
INSERT INTO `unique_numbers` VALUES (91, 1);
INSERT INTO `unique_numbers` VALUES (92, 1);
INSERT INTO `unique_numbers` VALUES (93, 1);
INSERT INTO `unique_numbers` VALUES (94, 1);
INSERT INTO `unique_numbers` VALUES (95, 1);
INSERT INTO `unique_numbers` VALUES (96, 1);
INSERT INTO `unique_numbers` VALUES (97, 1);
INSERT INTO `unique_numbers` VALUES (98, 1);
INSERT INTO `unique_numbers` VALUES (99, 1);
INSERT INTO `unique_numbers` VALUES (100, 1);
INSERT INTO `unique_numbers` VALUES (101, 1);

-- ----------------------------
-- Table structure for user
-- ----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `openId` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `nickName` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `avatarUrl` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `userid` int NULL DEFAULT NULL,
  `phone` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `detail` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `globalid`(`openId`(191) ASC) USING BTREE,
  INDEX `userid`(`userid` ASC) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 121 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of user
-- ----------------------------
INSERT INTO `user` VALUES (67, 'olrr74qOhuSv1AeAtSqNvu3xZhO0', '马先生', '', 10041, '13600000000', '不说');
INSERT INTO `user` VALUES (68, 'olrr74gbjhKH5plKobsgDrvims7w', '', '', 10042, NULL, NULL);
INSERT INTO `user` VALUES (69, 'olrr74pGDKD2rOZbJGETE24LlstY', '', '', 10043, NULL, NULL);
INSERT INTO `user` VALUES (70, 'olrr74tBlcKavXbjKKBlLG0dJBJY', '', '', 10044, NULL, NULL);
INSERT INTO `user` VALUES (71, 'olrr74pHh3lUb4n7Gj3mU1iDRUgA', '', '', 10045, NULL, NULL);
INSERT INTO `user` VALUES (72, 'olrr74jQq3I6UKcQIR93sYGtTKWc', '', '', 10046, NULL, NULL);
INSERT INTO `user` VALUES (73, 'olrr74svFP-VL7SUHX3RAEdV4EaI', '', '', 10047, NULL, NULL);
INSERT INTO `user` VALUES (74, 'olrr74l_cqroOllJhWLwg4tgUz7g', '', '', 10048, NULL, NULL);
INSERT INTO `user` VALUES (75, 'olrr74tOI-2GDScSdJZpXKiC7FaU', '', '', 10049, NULL, NULL);
INSERT INTO `user` VALUES (76, 'olrr74kCRowG44q2Ze3MEcuoPVSo', '', '', 10050, NULL, NULL);
INSERT INTO `user` VALUES (77, 'olrr74tyaJksdPI8p2NbnnfOGU9E', '', '', 10051, NULL, NULL);
INSERT INTO `user` VALUES (78, 'olrr74vKhkW8vcaJGUYxiNqCoDP8', '', '', 10052, NULL, NULL);
INSERT INTO `user` VALUES (79, 'olrr74hY_jEUq2ZihEHoC4F3wRY4', '', '', 10053, NULL, NULL);
INSERT INTO `user` VALUES (80, 'olrr74ud2QGD5ziMnUmBKtovp2VU', '', '', 10055, NULL, NULL);
INSERT INTO `user` VALUES (81, 'olrr74lO6kfkeIVjx3tO_S3Wn1Z0', '', '', 10056, NULL, NULL);
INSERT INTO `user` VALUES (82, 'olrr74ibEkejNa_BdXr7P70oJY_M', '', '', 10057, NULL, NULL);
INSERT INTO `user` VALUES (83, 'olrr74n5Mstr1arJNZeBdJ8Opa9M', '', '', 10058, NULL, NULL);
INSERT INTO `user` VALUES (84, 'olrr74lDdrdx6GF7qjDslGJbVZms', '', '', 10059, NULL, NULL);
INSERT INTO `user` VALUES (85, 'olrr74sL0Mq1l0xwAHfygUNdlE2U', '', '', 10060, NULL, NULL);
INSERT INTO `user` VALUES (86, 'olrr74prNgirbLjT9uqJoub-fOPI', '', '', 10061, NULL, NULL);
INSERT INTO `user` VALUES (87, 'olrr74p0OQcZoGb2BIaZKIvwkzR4', '', '', 10062, NULL, NULL);
INSERT INTO `user` VALUES (88, 'olrr74oSaJQV28S33Li9HNqL6cvU', '', '', 10063, NULL, NULL);
INSERT INTO `user` VALUES (89, 'olrr74oYLAzCBzsnfI2lNDdT7g_0', '', '', 10064, NULL, NULL);
INSERT INTO `user` VALUES (90, 'olrr74s6Agfe5U5lSn4G1tMBRMuU', '', '', 10065, NULL, NULL);
INSERT INTO `user` VALUES (91, 'olrr74p_aHq0J5ZfgVdipoDDVPZM', '', '', 10066, NULL, NULL);
INSERT INTO `user` VALUES (92, 'olrr74m_UyViF5XdU4n2x9a1aIWc', '', '', 10067, NULL, NULL);
INSERT INTO `user` VALUES (93, 'olrr74vjAbIPaN12hKfAONtOkczc', '', '', 10068, NULL, NULL);
INSERT INTO `user` VALUES (94, 'olrr74k8CJXz4EQl9vDjoh9LSd7U', '', '', 10069, NULL, NULL);
INSERT INTO `user` VALUES (95, 'olrr74iKhWMcXfN0er9a8WyXdEgk', '', '', 10070, NULL, NULL);
INSERT INTO `user` VALUES (96, 'olrr74qM7Ce3vcbghDsUJu613Uao', '', '', 10071, NULL, NULL);
INSERT INTO `user` VALUES (97, 'olrr74qhMH5kihIGUHAfjfPneKhs', '', '', 10072, NULL, NULL);
INSERT INTO `user` VALUES (98, 'olrr74tjmMlsgRia6iYiBXuW6ctE', '', '', 10073, NULL, NULL);
INSERT INTO `user` VALUES (99, 'olrr74n4WTxrFAwBUrLKeXjReTxc', '', '', 10074, NULL, NULL);
INSERT INTO `user` VALUES (100, 'olrr74teQpfY4geHly1xQPlb7O9U', '', '', 10075, NULL, NULL);
INSERT INTO `user` VALUES (101, 'olrr74jW1fPpwF1iCMCfbfhbe3xQ', '', '', 10076, NULL, NULL);
INSERT INTO `user` VALUES (102, 'olrr74nKKttZeGEt6hdwKAHupRq4', '', '', 10077, NULL, NULL);
INSERT INTO `user` VALUES (103, 'olrr74m-SwzMd9fXI4SGIMRJLSng', '', '', 10078, NULL, NULL);
INSERT INTO `user` VALUES (104, 'olrr74rJaIHps1ymWx5Gh_8EpfCE', '', '', 10079, NULL, NULL);
INSERT INTO `user` VALUES (105, 'olrr74jg7E9aUNURi5qqirvPordw', '', '', 10080, NULL, NULL);
INSERT INTO `user` VALUES (106, 'olrr74imX14CJohidgTEPIHqpZiw', '', '', 10081, NULL, NULL);
INSERT INTO `user` VALUES (107, 'olrr74henV4LiNzNHz9oB37OMMtc', '', '', 10082, NULL, NULL);
INSERT INTO `user` VALUES (108, 'olrr74pZpg4xY58uspzsidQymENs', '', '', 10083, NULL, NULL);
INSERT INTO `user` VALUES (109, 'olrr74n8zao8sHEOpQ7nyZ_EQpBk', '', '', 10084, NULL, NULL);
INSERT INTO `user` VALUES (110, 'olrr74uwX2IxhVOe4lxwpDzDTU1I', '', '', 10085, NULL, NULL);
INSERT INTO `user` VALUES (111, 'olrr74pGzFhtSqfiPW7Tm8nZDi-U', '', '', 10086, NULL, NULL);
INSERT INTO `user` VALUES (112, 'olrr74hiufEPystYnMDlPdbqgxvE', '', '', 10087, NULL, NULL);
INSERT INTO `user` VALUES (113, 'olrr74mCuz148KC2PsIr_0eX-Lxg', '', '', 10088, NULL, NULL);
INSERT INTO `user` VALUES (114, 'olrr74hHjB9HvIZuknJjKk-mJAk8', '', '', 10090, NULL, NULL);
INSERT INTO `user` VALUES (115, 'olrr74pN4jFFTT1sCnuvaLvA5pnY', '', '', 10092, NULL, NULL);
INSERT INTO `user` VALUES (116, 'olrr74mHclmEGozfxHfzcp6BSm2Y', '', '', 10093, NULL, NULL);
INSERT INTO `user` VALUES (117, 'olrr74voPLeqJ4aesVKikxeun7aA', '', '', 10094, NULL, NULL);
INSERT INTO `user` VALUES (118, 'olrr74lJTB7i14bhhLkom_ky8HwY', '', '', 10097, NULL, NULL);
INSERT INTO `user` VALUES (119, 'olrr74oPTn0G7J77a0vTuAAf74eQ', '', '', 10100, NULL, NULL);
INSERT INTO `user` VALUES (120, 'olrr74t9rrNvuRoDTE5NspEVOQrw', '', '', 10101, NULL, NULL);

-- ----------------------------
-- Table structure for webapp_user
-- ----------------------------
DROP TABLE IF EXISTS `webapp_user`;
CREATE TABLE `webapp_user`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `nickname` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `phone` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `h` varchar(250) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `dt` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`, `phone`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 33 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of webapp_user
-- ----------------------------
INSERT INTO `webapp_user` VALUES (26, '郭先生', '13671920000', NULL, '2025-04-23 19:23:07');
INSERT INTO `webapp_user` VALUES (27, '刘先生', '18910070000', NULL, '2025-04-23 19:23:02');
INSERT INTO `webapp_user` VALUES (28, '11410000', '13911410000', '啊', '2025-04-23 19:23:24');

-- ----------------------------
-- Table structure for webuser
-- ----------------------------
DROP TABLE IF EXISTS `webuser`;
CREATE TABLE `webuser`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `user` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `pwd` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 2 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of webuser
-- ----------------------------
INSERT INTO `webuser` VALUES (1, 'admin', '1');

SET FOREIGN_KEY_CHECKS = 1;
