%% coding: utf-8
-module(api_service_order_application_table).

-compile(export_all).




init(Req, Opts) ->
  {cowboy_rest, Req, Opts}.

allowed_methods(Req, State) ->
  {[<<"POST">>], Req, State}.

content_types_accepted(Req, State) ->
  Handlers =
    [{<<"application/x-www-form-urlencoded">>, json_post}, %%web æ¥å£
     {<<"application/json">>, json_post},
     {<<"application/json;charset=utf-8">>, json_post}],                  %%api æ¥å£
  {Handlers, Req, State}.


json_post(Req, State) ->
  %% post解析
  {ok, A, _} = cowboy_req:read_body(Req),
  Map = jsx:decode(A, [return_maps]),
  Phone = maps:get(<<"phone">>, Map),
  Orderid = maps:get(<<"orderid">>, Map),


  


   io:format("api_service_order*****------>     ~p~n", [{Phone,Orderid}]),
  
  
  
  
  
  Result =
    try
      Sql3 =
        lists:flatten(
          io_lib:format("insert into  application_table  (phone,orderid) values('~s','~s') ",
            [Phone,Orderid])),

      io:format("sql:::::~s~n", [Sql3]),

      try
        ok = mysql_poolboy:query(pool1, Sql3),



        jsx:encode([{<<"code">>, 0}, {<<"msg">>, <<"succ"/utf8>>}, {<<"data">>, <<"ok">>} ])
      catch
        _:_ ->
          jsx:encode([{<<"code">>, 1}, {<<"msg">>, <<"error"/utf8>>}, {<<"data">>, ""}])
      end
    catch
      _:_ ->
        jsx:encode([{<<"code">>, 1}, {<<"msg">>, <<"error param"/utf8>>}, {<<"data">>, ""}])
    end,

  
  

%%  Param="appid="++?Appid++"&secret="++?Secret++"&js_code=" ++ binary_to_list( Code) ++ "&grant_type=authorization_code",
 %% io:format("Param------>     ~p~n", [Param]),

%%  ReqHeaders = [{<<"Content-Type">>, <<"application/x-www-form-urlencoded">>}],
%%  {ok, _, _, Ref3} = hackney:request(post, <<"https://api.weixin.qq.com/sns/jscode2session">>,ReqHeaders, Param),
%%  {ok, Body2} = hackney:body(Ref3),


%%  Encrypted=base64:encode(Body2),
 %%  io:format("Original data: ~p~n", [Body2]),  %% 输出原始数据
  %% io:format("Encrypted data: ~p~n", [Encrypted]),  %% 输出加密后的数据
  Req11 = cowboy_req:set_resp_header(<<"access-control-allow-origin">>, <<$*>>, Req),

  Req21 = cowboy_req:set_resp_header(<<"access-control-allow-methods">>, <<"POST">>, Req11),

  Req31 = cowboy_req:set_resp_header(<<"access-control-allow-headers">>, <<"content-type">>, Req21),
  NewReq11 = cowboy_req:set_resp_body(Result, Req31),
  {true, NewReq11, State}.
