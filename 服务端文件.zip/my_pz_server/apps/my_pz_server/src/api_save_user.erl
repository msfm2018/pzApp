%% coding: utf-8
-module(api_save_user).

-compile(export_all).

init(Req, Opts) ->
  {cowboy_rest, Req, Opts}.

allowed_methods(Req, State) ->
  {[<<"POST">>], Req, State}.

content_types_accepted(Req, State) ->
  Handlers =
    [{<<"application/x-www-form-urlencoded">>, json_post}, %%web Ã¦ÂÂ¥Ã¥ÂÂ£
     {<<"application/json">>, json_post},
     {<<"application/json;charset=utf-8">>, json_post}],                  %%api Ã¦ÂÂ¥Ã¥ÂÂ£
  {Handlers, Req, State}.

json_post(Req, State) ->
  case cowboy_req:header(<<"authorization">>, Req) of
    undefined ->
      cowboy_req:reply(401, [], <<"Unauthorized">>, Req, State);
    Token ->
      case validate_token(Token) of
        true ->
          handle_post_request(Req, State);
        false ->
          cowboy_req:reply(403, [], <<"Forbidden">>, Req, State)
      end
  end.

handle_post_request(Req, State) ->
  {ok, A, _} = cowboy_req:read_body(Req),
  Map = jsx:decode(A, [return_maps]),
  OpenId = maps:get(<<"openid">>, Map),
  Name = maps:get(<<"name">>, Map),
  Avatarurl = maps:get(<<"avatarurl">>, Map),
  UserId = maps:get(<<"userid">>, Map),
  Result = save_user(OpenId, Name, Avatarurl, UserId),
  Resp = jsx:encode(Result),
  NewReq = cowboy_req:set_resp_header(<<"access-control-allow-origin">>, <<"*">>, Req),
  NewReq1 =
    cowboy_req:set_resp_header(<<"access-control-allow-methods">>, <<"POST">>, NewReq),
  NewReq2 =
    cowboy_req:set_resp_header(<<"access-control-allow-headers">>,
                               <<"content-type">>,
                               NewReq1),
  NewReq3 = cowboy_req:set_resp_body(Resp, NewReq2),
  {true, NewReq3, State}.

validate_token(_) ->
  true.

save_user(OpenId, Name, Avatarurl, UserId) ->
  Sql3 =
    lists:flatten(
      io_lib:format("insert into  user  (openId,nickName,avatarUrl,userid) values('~s','~"
                    "s','~s','~s') ",
                    [binary_to_list(OpenId),
                     binary_to_list(Name),
                     binary_to_list(Avatarurl),
                     integer_to_list(UserId)])),

  try
    mysql_poolboy:query(pool1, Sql3),

    jsx:encode([{<<"code">>, 0}, {<<"msg">>, <<"succ"/utf8>>}, {<<"data">>, <<"ok">>}])
  catch
    _:_ ->
      jsx:encode([{<<"code">>, 1}, {<<"msg">>, <<"error"/utf8>>}, {<<"data">>, ""}])
  end.
