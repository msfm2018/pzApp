%% coding: utf-8
-module(webapp_customInfo).

-compile(export_all).

init(Req, Opts) ->
  {cowboy_rest, Req, Opts}.

allowed_methods(Req, State) ->
  {[<<"POST">>], Req, State}.

content_types_accepted(Req, State) ->
  Handlers =
    [{<<"application/x-www-form-urlencoded">>, json_post}, %%web æ¥å£
     {<<"application/json">>, json_post},
     {<<"application/json;charset=utf-8">>, json_post}],                  %%api æ¥å£
  {Handlers, Req, State}.


json_post(Req, State) ->
  %% post解析
  {ok, A, _} = cowboy_req:read_body(Req),
  Map = jsx:decode(A, [return_maps]),
  Nickname = maps:get(<<"nickname">>, Map),

  Phone = maps:get(<<"phone">>, Map), 
  H = maps:get(<<"h">>, Map), 
  
  Result =
    try

     
      Sql3 =
        lists:flatten(
          io_lib:format("insert into  webapp_user  (nickname,phone,h) values('~s','~s','~s') ",
            [binary_to_list( Nickname),binary_to_list(Phone),binary_to_list(H)])),
      io:format("sql:::::~p~n", [Sql3]),

      try
        Rst = mysql_poolboy:query(pool1, Sql3),

        % io:format("Rst *****------>     ~p~n", [{Rst}]),

        jsx:encode([{<<"code">>, 0}, {<<"msg">>, <<"succ"/utf8>>}, {<<"data">>, <<"ok">>} ])
      catch
        _:_ ->
          jsx:encode([{<<"code">>, 1}, {<<"msg">>, <<"error"/utf8>>}, {<<"data">>, ""}])
      end
    catch
      _:_ ->
        jsx:encode([{<<"code">>, 1}, {<<"msg">>, <<"error param"/utf8>>}, {<<"data">>, ""}])
    end,

  NewReq11 = cowboy_req:set_resp_body(Result, Req),
  {true, NewReq11, State}.
