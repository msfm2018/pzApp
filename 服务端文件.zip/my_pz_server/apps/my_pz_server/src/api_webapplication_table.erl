%% coding: utf-8
-module(api_webapplication_table).

-compile(export_all).
init(Req, Opts) ->
  {cowboy_rest, Req, Opts}.
allowed_methods(Req, State) ->
  {[<<"GET">>], Req, State}.


content_types_provided(Req, State) ->
  {[

    {<<"application/json">>, func_rooms_members_data}

  ], Req, State}.


func_rooms_members_data(Req, State) ->



 Vv =
    try
   

      Sql3 ="SELECT b.name,b.phone,b.address,c.name as name1,c.phone as phone1,c.hospital,c.department,c.orderdate,c.gender,c.other,c.orderid from application_table a,companions b,service_order c WHERE a.isprocessed='0' and a.orderid=c.orderid AND b.phone=a.phone",
      io:format(":::::::::~p~n", ["api_webapplication_table"]),
      try
        {ok, FieldList, DataList} = mysql_poolboy:query(pool1, Sql3),
       
          case DataList of
            [] ->
              jsx:encode([{<<"code">>, -1}, {<<"msg">>, <<"no data"/utf8>>}, {<<"data">>, []}]);
            _ ->
              V =  [lists:zip(FieldList, D_DATA) || D_DATA <- DataList],
              jsx:encode([{<<"code">>, 0}, {<<"msg">>, <<"succ"/utf8>>}, {<<"data">>, V}])
          end
      
      catch
        _:_ ->
          jsx:encode([{<<"code">>, -1}, {<<"msg">>, <<"error"/utf8>>}, {<<"data">>, ""}])
      end
    catch
      _:_ ->
        jsx:encode([{<<"code">>, -1}, {<<"msg">>, <<"error param"/utf8>>}, {<<"data">>, ""}])
    end,







  {Vv, Req, State}.















  % json_post(Req, State) ->
  %   %% post解析
  %   {ok, A, _} = cowboy_req:read_body(Req),
  %   Map = jsx:decode(A, [return_maps]),
  %   Code = maps:get(<<"code">>, Map),
  %   io:format("Map*****------>     ~p~n", [Map]),
  
  %   Param="appid="++?Appid++"&secret="++?Secret++"&js_code=" ++ binary_to_list( Code) ++ "&grant_type=authorization_code",
  %   io:format("Param------>     ~p~n", [Param]),
  
  %   ReqHeaders = [{<<"Content-Type">>, <<"application/x-www-form-urlencoded">>}],
  %   {ok, _, _, Ref3} = hackney:request(post, <<"https://api.weixin.qq.com/sns/jscode2session">>,ReqHeaders, Param),
  %   {ok, Body2} = hackney:body(Ref3),
  
  
  
  %   AA=mysql_poolboy:transaction(pool1, fun (Pid) ->
  %     mysql:query(Pid, "insert into  unique_numbers  (number) values(?)", [1]),
  %     SQL = "SELECT MAX(ID) FROM unique_numbers",
  
  %     % {ok, Result} = mysql:query(Pid, SQL, [])
  %    mysql:query(Pid, SQL, [])
  
  % end),
  %  {atomic,{ok,[<<"MAX(ID)">>],[[MaxID]]}}=AA,
  %  io:format("Original Body2 data: ~p~n", [Body2]),  %% 输出原始数据
  %  JSONDATA=jsx:encode([{<<"maxid">>, MaxID+10000},  {<<"data">>,Body2 }]),
  
  % io:format("ABC------>     ~p~n", [AA]),
  %   Encrypted=base64:encode(JSONDATA),
  %   io:format("Original data: ~p~n", [JSONDATA]),  %% 输出原始数据
  %   io:format("Encrypted data: ~p~n", [Encrypted]),  %% 输出加密后的数据
  %   Req11 = cowboy_req:set_resp_header(<<"access-control-allow-origin">>, <<$*>>, Req),
  
  %   Req21 = cowboy_req:set_resp_header(<<"access-control-allow-methods">>, <<"POST">>, Req11),
  
  %   Req31 = cowboy_req:set_resp_header(<<"access-control-allow-headers">>, <<"content-type">>, Req21),
  %   NewReq11 = cowboy_req:set_resp_body(Encrypted, Req31),
  %   {true, NewReq11, State}.
  