%%%-------------------------------------------------------------------
%% @doc my_pz_server public API
%% @end
%%%-------------------------------------------------------------------

-module(my_pz_server_app).

-behaviour(application).

-export([start/2, stop/1]).

start(_StartType, _StartArgs) ->
    Dispatch =
        cowboy_router:compile([{'_',
                                [{"/webapp_customInfo", webapp_customInfo, []}, %%存储webapp用户信息
                                 % -------------------------------分界线------------------------------------------------
                                 {"/api_weblogin", api_weblogin, []},    %%wx接口文件
                                 {"/api_webapplication_table",
                                  api_webapplication_table,
                                  []},    %%申请表
                                 {"/api_webapplication_table_handle",
                                  api_webapplication_table_handle,
                                  []},    %%申请表 管理员处理情况
                                 {"/api_webcompanions", api_webcompanions, []},    %%wx接口文件
                                 {"/api_webcompanionspass",
                                  api_webcompanionspass,
                                  []},    %%申请人是否可使用
                                 {"/api_wxlogin", api_wxlogin, []},    %%wx接口文件
                                 {"/user/api_save_user", api_save_user, []}, %%存储用户信息
                                 {"/api_user_info", api_user_info, []},%%取得用户信息
                                 {"/api_user_info_update", api_user_info_update, []},%%取得用户信息
                                 {"/api_swiper", api_swiper, []}, %%滚屏
                                 % {"/api_grid", api_grid, []}   , %%九宫格
                                 {"/api_service_order_get", api_service_order_get, []}, %%订单数据
                                 {"/api_service_order_del", api_service_order_del, []}, %%
                                 {"/api_service_order_all", api_service_order_all, []}, %%陪诊员看到的所有订单
                                 {"/api_service_order_application_table",
                                  api_service_order_application_table,
                                  []}, %%陪诊员申请订单
                                 {"/api_service_order_application_table_agent",
                                  api_service_order_application_table_agent,
                                  []}, %%陪诊员申请订单
                                 % {"/api_service_order_finish", api_service_order_finish, []}   , %%修改订单完成状态
                                 {"/api_service_order_application_table_myfinish",
                                  api_service_order_application_table_myfinish,
                                  []}, %%查询我完成的订单
                                 {"/api_verification_code_get",
                                  api_companions_verification_code_send,
                                  []}, %%
                                 {"/api_verification_code_check",
                                  api_companions_verification_code_check,
                                  []}, %% 检查是否注册了已经
                                 {"/api_companions", api_companions, []}, %% 检查是否注册了已经
                                 {"/api_companions_login", api_companions_login, []}, %% 陪诊员登录
                                 {"/api_getphone", api_getphone, []},  %%企业才能获得电话
                                 {"/api_decrypt", api_decrypt, []},   %%base64加解密
                                 {"/api_server_info_get", api_server_info_get, []},   %%服务信息
                                 {"/api_service_order", api_service_order, []},   %%订单信息
                                 {"/api_askphone", api_askphone, []},   %%咨询电话
                                 {"/", toppage_h, []}]}]),
    {ok, _} = cowboy:start_clear(http, [{port, 9091}], #{env => #{dispatch => Dispatch}}),

    my_pz_server_sup:start_link().

stop(_State) ->
    ok.

%% internal functions
