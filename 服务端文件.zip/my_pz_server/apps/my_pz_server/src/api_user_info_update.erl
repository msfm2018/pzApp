%% coding: utf-8
-module(api_user_info_update).

-compile(export_all).




init(Req, Opts) ->
  {cowboy_rest, Req, Opts}.

allowed_methods(Req, State) ->
  {[<<"POST">>], Req, State}.

content_types_accepted(Req, State) ->
  Handlers =
    [{<<"application/x-www-form-urlencoded">>, json_post}, %%web æ¥å£
     {<<"application/json">>, json_post},
     {<<"application/json;charset=utf-8">>, json_post}],                  %%api æ¥å£
  {Handlers, Req, State}.


json_post(Req, State) ->
  %% post解析
  {ok, A, _} = cowboy_req:read_body(Req),
  Map = jsx:decode(A, [return_maps]),
  Userid = maps:get(<<"userid">>, Map),
  Nick = maps:get(<<"nick">>, Map),
  Phone = maps:get(<<"phone">>, Map),
  Detail = maps:get(<<"detail">>, Map),
 
  % io:format("api_userinfoupdate*****------>     ~p~n", [{Userid,Nick,Phone,Detail}]),



  Result =
    try

          Sql3 = lists:flatten(io_lib:format("update  user set nickName='~s',phone='~s',detail='~s' where userid='~s'", [  binary_to_list(Nick), binary_to_list(Phone),binary_to_list(Detail), integer_to_list(Userid)])),
     
      % io:format("~p~n", [Sql3]),

      try
         mysql_poolboy:query(pool1, Sql3),
      

        jsx:encode([{<<"code">>, 0}, {<<"msg">>, <<"succ"/utf8>>}, {<<"data">>, ""}])
      catch
        _:_ ->
          jsx:encode([{<<"code">>, 1}, {<<"msg">>, <<"error"/utf8>>}, {<<"data">>, ""}])
      end
    catch
      _:_ ->
        jsx:encode([{<<"code">>, 1}, {<<"msg">>, <<"error param"/utf8>>}, {<<"data">>, ""}])
    end,




    % io:format("result*****------>     ~p~n", [Result]),






  Req11 = cowboy_req:set_resp_header(<<"access-control-allow-origin">>, <<$*>>, Req),

  Req21 = cowboy_req:set_resp_header(<<"access-control-allow-methods">>, <<"POST">>, Req11),

  Req31 = cowboy_req:set_resp_header(<<"access-control-allow-headers">>, <<"content-type">>, Req21),
  NewReq11 = cowboy_req:set_resp_body(Result, Req31),
  {true, NewReq11, State}.
