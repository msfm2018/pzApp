%% coding: utf-8
-module(api_service_order_del).

-compile(export_all).


init(Req, Opts) ->
  {cowboy_rest, Req, Opts}.

allowed_methods(Req, State) ->
  {[<<"POST">>], Req, State}.

content_types_accepted(Req, State) ->
  Handlers =
    [{<<"application/x-www-form-urlencoded">>, json_post}, %%web æ¥å£
     {<<"application/json">>, json_post},
     {<<"application/json;charset=utf-8">>, json_post}],                  %%api æ¥å£
  {Handlers, Req, State}.


json_post(Req, State) ->
  %% post解析
  {ok, A, _} = cowboy_req:read_body(Req),
  Map = jsx:decode(A, [return_maps]),
  Orderid = maps:get(<<"orderid">>, Map),
  % io:format("api_service_order_del:::::Key *****------>     ~p~n", [{Orderid}]),
  
  
  
  
  Result =
    try
   


    Sql3 = lists:flatten(io_lib:format("update  service_order set delflag='-1' where orderid='~s'", [  binary_to_list(Orderid)])),
     
      

      % io:format("sql:::::~p~n", [Sql3]),
      try
        {ok, FieldList, DataList} = mysql_poolboy:query(pool1, Sql3),
        V =
          case DataList of
            [] ->
              jsx:encode([{<<"code">>, -1}, {<<"msg">>, <<"no data"/utf8>>}, {<<"data">>, []}]);
            _ ->
              [lists:zip(FieldList, D_DATA) || D_DATA <- DataList]
          end,
        jsx:encode([{<<"code">>, 0}, {<<"msg">>, <<"succ"/utf8>>}, {<<"data">>, V}])
      catch
        _:_ ->
          jsx:encode([{<<"code">>, 1}, {<<"msg">>, <<"error"/utf8>>}, {<<"data">>, ""}])
      end
    catch
      _:_ ->
        jsx:encode([{<<"code">>, 1}, {<<"msg">>, <<"error param"/utf8>>}, {<<"data">>, ""}])
    end,

  
  
  
  
  Req11 = cowboy_req:set_resp_header(<<"access-control-allow-origin">>, <<$*>>, Req),

  Req21 = cowboy_req:set_resp_header(<<"access-control-allow-methods">>, <<"POST">>, Req11),

  Req31 = cowboy_req:set_resp_header(<<"access-control-allow-headers">>, <<"content-type">>, Req21),

  NewReq11 = cowboy_req:set_resp_body(Result, Req31),
  {true, NewReq11, State}.
