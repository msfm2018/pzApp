%% coding: utf-8
-module(api_service_order).

-compile(export_all).




init(Req, Opts) ->
  {cowboy_rest, Req, Opts}.

allowed_methods(Req, State) ->
  {[<<"POST">>], Req, State}.

content_types_accepted(Req, State) ->
  Handlers =
    [{<<"application/x-www-form-urlencoded">>, json_post}, %%web æ¥å£
     {<<"application/json">>, json_post},
     {<<"application/json;charset=utf-8">>, json_post}],                  %%api æ¥å£
  {Handlers, Req, State}.


json_post(Req, State) ->
  %% post解析
  {ok, A, _} = cowboy_req:read_body(Req),
  Map = jsx:decode(A, [return_maps]),
  Phone = maps:get(<<"phone">>, Map),
  Name = maps:get(<<"name">>, Map),
  Hospital = maps:get(<<"hospital">>, Map),
  Department = maps:get(<<"department">>, Map),
  Gender = maps:get(<<"gender">>, Map),
  OrderDate = maps:get(<<"orderdate">>, Map),
  Other = maps:get(<<"other">>, Map),
  Userid = maps:get(<<"userid">>, Map),
  Orderid = maps:get(<<"orderid">>, Map),
  Serviceid = maps:get(<<"serviceid">>, Map),

  


   io:format("api_service_order*****------>     ~p~n", [{Phone,Name,Hospital,Department,Gender,OrderDate,Other,Userid,Orderid,Serviceid}]),
  
  
  
  
  
  Result =
    try
      Sql3 =
        lists:flatten(
          io_lib:format("insert into  service_order  (phone,name,hospital,department,gender,orderdate,other,userid,orderid,serviceid) values('~s','~s','~s','~s','~s','~s','~s','~s','~s','~s') ",
            [Phone,Name,Hospital,Department,Gender,OrderDate,Other,integer_to_list(Userid),Orderid,Serviceid])),

      io:format("sql:::::~s~n", [Sql3]),

      try
        ok = mysql_poolboy:query(pool1, Sql3),



        jsx:encode([{<<"code">>, 0}, {<<"msg">>, <<"succ"/utf8>>}, {<<"data">>, <<"ok">>} ])
      catch
        _:_ ->
          jsx:encode([{<<"code">>, 1}, {<<"msg">>, <<"error"/utf8>>}, {<<"data">>, ""}])
      end
    catch
      _:_ ->
        jsx:encode([{<<"code">>, 1}, {<<"msg">>, <<"error param"/utf8>>}, {<<"data">>, ""}])
    end,

  
  

%%  Param="appid="++?Appid++"&secret="++?Secret++"&js_code=" ++ binary_to_list( Code) ++ "&grant_type=authorization_code",
 %% io:format("Param------>     ~p~n", [Param]),

%%  ReqHeaders = [{<<"Content-Type">>, <<"application/x-www-form-urlencoded">>}],
%%  {ok, _, _, Ref3} = hackney:request(post, <<"https://api.weixin.qq.com/sns/jscode2session">>,ReqHeaders, Param),
%%  {ok, Body2} = hackney:body(Ref3),


%%  Encrypted=base64:encode(Body2),
 %%  io:format("Original data: ~p~n", [Body2]),  %% 输出原始数据
  %% io:format("Encrypted data: ~p~n", [Encrypted]),  %% 输出加密后的数据
  Req11 = cowboy_req:set_resp_header(<<"access-control-allow-origin">>, <<$*>>, Req),

  Req21 = cowboy_req:set_resp_header(<<"access-control-allow-methods">>, <<"POST">>, Req11),

  Req31 = cowboy_req:set_resp_header(<<"access-control-allow-headers">>, <<"content-type">>, Req21),
  NewReq11 = cowboy_req:set_resp_body(Result, Req31),
  {true, NewReq11, State}.
