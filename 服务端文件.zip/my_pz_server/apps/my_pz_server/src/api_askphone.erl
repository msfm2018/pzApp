%% coding: utf-8
-module(api_askphone).
-export([init/2, allowed_methods/2, content_types_provided/2, func_rooms_members_data/2]).

init(Req, Opts) ->
  {cowboy_rest, Req, Opts}.

allowed_methods(Req, State) ->
  {[<<"GET">>], Req, State}.

content_types_provided(Req, State) ->
  {[{<<"application/json">>, func_rooms_members_data}], Req, State}.

func_rooms_members_data(Req, State) ->
  ResponseJson =
    case fetch_data_from_db() of
      {ok, []} ->
        encode_json(-1, <<"no data">>, []);
      {ok, Data} ->
        encode_json(0, <<"succ">>, Data);
      {error, Reason} ->
        io:format("DB Error: ~p~n", [Reason]),
        encode_json(1, <<"error">>, <<>>)
    end,
  {ResponseJson, Req, State}.

%% -------------------------
%% 辅助函数
%% -------------------------

fetch_data_from_db() ->
  Sql = "select * from ask",
  io:format(":::::::::~p~n", ["api_askphone"]),
  try
    case mysql_poolboy:query(pool1, Sql) of
      {ok, FieldList, DataList} ->
        DataMaps = [maps:from_list(lists:zip(FieldList, Row)) || Row <- DataList],
        {ok, DataMaps};
      Error -> {error, Error}
    end
  catch
    Type:Reason ->
      {error, {Type, Reason}}
  end.

encode_json(Code, Msg, Data) ->
  jsx:encode([{<<"code">>, Code}, {<<"msg">>, Msg}, {<<"data">>, Data}]).
