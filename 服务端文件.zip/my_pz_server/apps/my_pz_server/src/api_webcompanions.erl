%% coding: utf-8
-module(api_webcompanions).

-compile(export_all).
init(Req, Opts) ->
  {cowboy_rest, Req, Opts}.
allowed_methods(Req, State) ->
  {[<<"GET">>], Req, State}.


content_types_provided(Req, State) ->
  {[
    {<<"application/json">>, func_rooms_members_data}
  ], Req, State}.


func_rooms_members_data(Req, State) ->
 Vv =
    try
      Sql3 ="select *  from companions where availability=0",
      io:format(":::::::::~p~n", ["api_webcompanions"]),
      try
        {ok, FieldList, DataList} = mysql_poolboy:query(pool1, Sql3),
 
          case DataList of
            [] ->
              jsx:encode([{<<"code">>, -1}, {<<"msg">>, <<"no data"/utf8>>}, {<<"data">>, []}]);
            _ ->
            V=  [lists:zip(FieldList, D_DATA) || D_DATA <- DataList],
              jsx:encode([{<<"code">>, 0}, {<<"msg">>, <<"succ"/utf8>>}, {<<"data">>, V}])
          end
      
      catch
        _:_ ->
          jsx:encode([{<<"code">>, -1}, {<<"msg">>, <<"error"/utf8>>}, {<<"data">>, ""}])
      end
    catch
      _:_ ->
        jsx:encode([{<<"code">>, -1}, {<<"msg">>, <<"error param"/utf8>>}, {<<"data">>, ""}])
    end,

  {Vv, Req, State}.

