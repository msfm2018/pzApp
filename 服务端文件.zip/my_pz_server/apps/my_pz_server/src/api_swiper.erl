%% coding: utf-8
-module(api_swiper).
-compile(export_all).
init(Req, Opts) ->
  {cowboy_rest, Req, Opts}.
allowed_methods(Req, State) ->
  {[<<"GET">>], Req, State}.


content_types_provided(Req, State) ->
  {[

    {<<"application/json">>, func_rooms_members_data}

  ], Req, State}.


func_rooms_members_data(Req, State) ->



 Vv =
    try
   

      Sql3 ="select *  from swiper ",
      % io:format("~p~n", [Sql3]),
      try
        {ok, FieldList, DataList} = mysql_poolboy:query(pool1, Sql3),
        V =
          case DataList of
            [] ->
              jsx:encode([{<<"code">>, -1}, {<<"msg">>, <<"no data"/utf8>>}, {<<"data">>, []}]);
            _ ->
              [lists:zip(FieldList, D_DATA) || D_DATA <- DataList]
          end,
        jsx:encode([{<<"code">>, 0}, {<<"msg">>, <<"succ"/utf8>>}, {<<"data">>, V}])
      catch
        _:_ ->
          jsx:encode([{<<"code">>, 1}, {<<"msg">>, <<"error"/utf8>>}, {<<"data">>, ""}])
      end
    catch
      _:_ ->
        jsx:encode([{<<"code">>, 1}, {<<"msg">>, <<"error param"/utf8>>}, {<<"data">>, ""}])
    end,






                
  Req1 = cowboy_req:set_resp_header(<<"access-control-allow-origin">>, <<$*>>, Req),

  Req2 = cowboy_req:set_resp_header(<<"access-control-allow-methods">>, <<"POST">>, Req1),

  Req3 = cowboy_req:set_resp_header(<<"access-control-allow-headers">>, <<"content-type">>, Req2),

  {Vv, Req3, State}.

