%% coding: utf-8
-module(api_webcompanionspass).

-compile(export_all).




init(Req, Opts) ->
  {cowboy_rest, Req, Opts}.

allowed_methods(Req, State) ->
  {[<<"POST">>], Req, State}.

content_types_accepted(Req, State) ->
  Handlers =
    [{<<"application/x-www-form-urlencoded">>, json_post}, %%web æ¥å£
     {<<"application/json">>, json_post},
     {<<"application/json;charset=utf-8">>, json_post}],                  %%api æ¥å£
  {Handlers, Req, State}.


json_post(Req, State) ->
  %% post解析
  {ok, A, _} = cowboy_req:read_body(Req),
  Map = jsx:decode(A, [return_maps]),
 

  Phone = maps:get(<<"phone">>, Map),
  N = maps:get(<<"n">>, Map),
  io:format("api_webcompanionspass*****------>     ~p~n", [{N ,Phone}]),

  Result =
  try




Sql3 =lists:flatten(io_lib:format("UPDATE companions set availability=~p WHERE phone = '~s'  ",  [N,binary_to_list( Phone)])),
io:format("api_webcompanionspass*****------>     ~p~n", [Sql3]),
mysql_poolboy:query(pool1, Sql3),

   



          jsx:encode([{<<"code">>, 1}, {<<"msg">>, <<"error param"/utf8>>}, {<<"data">>, []}])

    
  catch
    _:_ ->
      jsx:encode([{<<"code">>, 1}, {<<"msg">>, <<"error param"/utf8>>}, {<<"data">>, ""}])
  end,

  io:format("api_webcompanionspass*****------>     ~p~n", [Result]),
  NewReq11 = cowboy_req:set_resp_body(Result, Req),
  {true, NewReq11, State}.
