%% coding: utf-8
-module(api_getphone).

-compile(export_all).

% -define (Key,"appiduix3bedc440b726408&secret=ea53a2ffdaf18ed20dcfea822889c0664b4").
-define (Appid,"wx13bedc440b726408").
-define (Secret,"ea31fdaf18ed20dcfea822889c0664b4").

init(Req, Opts) ->
  {cowboy_rest, Req, Opts}.

allowed_methods(Req, State) ->
  {[<<"POST">>], Req, State}.

content_types_accepted(Req, State) ->
  Handlers =
    [{<<"application/x-www-form-urlencoded">>, json_post}, %%web æ¥å£
     {<<"application/json">>, json_post},
     {<<"application/json;charset=utf-8">>, json_post}],                  %%api æ¥å£
  {Handlers, Req, State}.


json_post(Req, State) ->
  %% post解析
  {ok, A, _} = cowboy_req:read_body(Req),
  Map = jsx:decode(A, [return_maps]),
  Code = maps:get(<<"code">>, Map),
  io:format("Code*****------>     ~p~n", [Code]),
  
  %电话号码取得不针对个人用户 必须是企业用户才可以

  Param="https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid="++?Appid++"&secret="++?Secret,


  io:format("Param------>     ~p~n", [Param]),

  ReqHeaders =[],
  Options=[],
  {ok, _, _, Ref3} = hackney:request(get, list_to_binary(Param),ReqHeaders, Options),
  {ok, Body2} = hackney:body(Ref3),
    io:format("Body2 phone*****------>     ~p~n", [Body2]),

  
    Map1 = jsx:decode(Body2, [return_maps]),
  

	  Access_token = maps:get(<<"access_token">>, Map1),
	    io:format("Access_token*****------>     ~p~n", [Access_token]),
		
	UrlB=	<<"https://api.weixin.qq.com/wxa/business/getuserphonenumber?access_token=",Access_token/binary >>,
	
	 io:format("UrlB*****------>     ~p~n", [UrlB]),
  ReqHeaders1 = [{<<"Content-Type">>, <<"application/x-www-form-urlencoded">>}],
  Param1=jsx:encode(#{code=>Code}),
  io:format("Param1 json*****------>     ~p~n", [Param1]),
  {ok, _, _, Ref4} = hackney:request(post, UrlB,ReqHeaders1, Param1),
  {ok, Body3} = hackney:body(Ref4),	
		  io:format("Body3 *****------>     ~p~n", [Body3]),
		
  
  Req11 = cowboy_req:set_resp_header(<<"access-control-allow-origin">>, <<$*>>, Req),

  Req21 = cowboy_req:set_resp_header(<<"access-control-allow-methods">>, <<"POST">>, Req11),

  Req31 = cowboy_req:set_resp_header(<<"access-control-allow-headers">>, <<"content-type">>, Req21),
  NewReq11 = cowboy_req:set_resp_body(Body2, Req31),
  {true, NewReq11, State}.
