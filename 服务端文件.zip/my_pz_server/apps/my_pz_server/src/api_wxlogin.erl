%% coding: utf-8
-module(api_wxlogin).

-compile(export_all).

% -define (Key,"appiduix3bedc440b726408&secret=ea53a2ffdaf18ed20dcfea822889c0664b4").
-define (Appid,"wx13bedc440b726408").
-define (Secret,"ea31fdaf18ed20dcfea822889c0664b4").


init(Req, Opts) ->
  {cowboy_rest, Req, Opts}.

allowed_methods(Req, State) ->
  {[<<"POST">>], Req, State}.

content_types_accepted(Req, State) ->
  Handlers =
    [{<<"application/x-www-form-urlencoded">>, json_post}, %%web æ¥å£
     {<<"application/json">>, json_post},
     {<<"application/json;charset=utf-8">>, json_post}],                  %%api æ¥å£
  {Handlers, Req, State}.



  % json_post(Req, State) ->
  %   %% post解析
  %   {ok, A, _} = cowboy_req:read_body(Req),
  %   Map = jsx:decode(A, [return_maps]),
  %   Code = maps:get(<<"code">>, Map),
  %   io:format("Map*****------>     ~p~n", [Map]),
  
  %   Param="appid="++?Appid++"&secret="++?Secret++"&js_code=" ++ binary_to_list( Code) ++ "&grant_type=authorization_code",
  %   io:format("Param------>     ~p~n", [Param]),
  
  %   ReqHeaders = [{<<"Content-Type">>, <<"application/x-www-form-urlencoded">>}],
  %   {ok, _, _, Ref3} = hackney:request(post, <<"https://api.weixin.qq.com/sns/jscode2session">>,ReqHeaders, Param),
  %   {ok, Body2} = hackney:body(Ref3),
  
  
  

  
  %   Encrypted=base64:encode(Body2),
  %   io:format("Original data: ~p~n", [Body2]),  %% 输出原始数据
  %   io:format("Encrypted data: ~p~n", [Encrypted]),  %% 输出加密后的数据
  %   Req11 = cowboy_req:set_resp_header(<<"access-control-allow-origin">>, <<$*>>, Req),
  
  %   Req21 = cowboy_req:set_resp_header(<<"access-control-allow-methods">>, <<"POST">>, Req11),
  
  %   Req31 = cowboy_req:set_resp_header(<<"access-control-allow-headers">>, <<"content-type">>, Req21),
  %   NewReq11 = cowboy_req:set_resp_body(Encrypted, Req31),
  %   {true, NewReq11, State}.
  



json_post(Req, State) ->
  %% post解析
  {ok, A, _} = cowboy_req:read_body(Req),
  Map = jsx:decode(A, [return_maps]),
  Code = maps:get(<<"code">>, Map),

  Param="appid="++?Appid++"&secret="++?Secret++"&js_code=" ++ binary_to_list( Code) ++ "&grant_type=authorization_code",

  ReqHeaders = [{<<"Content-Type">>, <<"application/x-www-form-urlencoded">>}],
  {ok, _, _, Ref3} = hackney:request(post, <<"https://api.weixin.qq.com/sns/jscode2session">>,ReqHeaders, Param),
  {ok, Body2} = hackney:body(Ref3),
  % <<"{\"session_key\":\"ZCtDSzG4\\/PW2IaKevCkHrQ==\",\"openid\":\"olrr74qOhuSv1AeAtSqNvu3xZhO0\"}">>
%   DecodedData = jsx:decode(Body2),
%    {ok, SessionKey} = proplists:get_value(<<"session_key">>, DecodedData),
%  {ok, OpenID} = proplists:get_value(<<"openid">>, DecodedData),

%   io:format("OpenID------>     ~p~n", [OpenID]),

% <<"{\"session_key\":\"yH+neJTK\\/WIbAoLnbdo\\/zw==\",\"openid\":\"olrr74qOhuSv1AeAtSqNvu3xZhO0\"}">>

   Data =Body2,%% <<"{\"session_key\":\"ZCtDSzG4\\/PW2IaKevCkHrQ==\",\"openid\":\"olrr74qOhuSv1AeAtSqNvu3xZhO0\"}">>,
   DecodedData = jsx:decode(Data),
   SessionKey = proplists:get_value(<<"session_key">>, DecodedData),
   OpenID = proplists:get_value(<<"openid">>, DecodedData),
  

  Result =
try

  Sql3 =
    lists:flatten(
      io_lib:format("SELECT * from user WHERE openId='~s' limit 1",[binary_to_list(OpenID)])),

  try
    {ok, FieldList, DataList} = mysql_poolboy:query(pool1, Sql3),
    V = case DataList of
          [] ->
            AA=mysql_poolboy:transaction(pool1, fun (Pid) ->
              mysql:query(Pid, "insert into  unique_numbers  (number) values(?)", [1]),
              SQL = "SELECT MAX(ID) FROM unique_numbers",
             mysql:query(Pid, SQL, [])
          
          end),
           {atomic,{ok,[<<"MAX(ID)">>],[[MaxID]]}}=AA,
           JSONDATA=[{<<"maxid">>, MaxID+10000},  {<<"data">>,Body2 }],
          
            % Encrypted=base64:encode(JSONDATA),
            jsx:encode([{<<"code">>, 0}, {<<"msg">>, <<"data"/utf8>>}, {<<"data">>, JSONDATA}]);
          _ ->
           C= [lists:zip(FieldList, D_DATA) || D_DATA <- DataList],
            jsx:encode([{<<"code">>, 2}, {<<"msg">>, <<"succ"/utf8>>}, {<<"data">>, C}])
        end
   

   
  catch
    _:_ ->
      jsx:encode([{<<"code">>, 1}, {<<"msg">>, <<"error"/utf8>>}, {<<"data">>, ""}])
  end
catch
  _:_ ->
    jsx:encode([{<<"code">>, 1}, {<<"msg">>, <<"error param"/utf8>>}, {<<"data">>, ""}])
end,


    Encrypted=base64:encode(Result),

    Req11 = cowboy_req:set_resp_header(<<"access-control-allow-origin">>, <<$*>>, Req),

    Req21 = cowboy_req:set_resp_header(<<"access-control-allow-methods">>, <<"POST">>, Req11),
  
    Req31 = cowboy_req:set_resp_header(<<"access-control-allow-headers">>, <<"content-type">>, Req21),
    NewReq11 = cowboy_req:set_resp_body(Encrypted, Req31),
    {true, NewReq11, State}.















  % json_post(Req, State) ->
  %   %% post解析
  %   {ok, A, _} = cowboy_req:read_body(Req),
  %   Map = jsx:decode(A, [return_maps]),
  %   Code = maps:get(<<"code">>, Map),
  %   io:format("Map*****------>     ~p~n", [Map]),
  
  %   Param="appid="++?Appid++"&secret="++?Secret++"&js_code=" ++ binary_to_list( Code) ++ "&grant_type=authorization_code",
  %   io:format("Param------>     ~p~n", [Param]),
  
  %   ReqHeaders = [{<<"Content-Type">>, <<"application/x-www-form-urlencoded">>}],
  %   {ok, _, _, Ref3} = hackney:request(post, <<"https://api.weixin.qq.com/sns/jscode2session">>,ReqHeaders, Param),
  %   {ok, Body2} = hackney:body(Ref3),
  
  
  
  %   AA=mysql_poolboy:transaction(pool1, fun (Pid) ->
  %     mysql:query(Pid, "insert into  unique_numbers  (number) values(?)", [1]),
  %     SQL = "SELECT MAX(ID) FROM unique_numbers",
  
  %     % {ok, Result} = mysql:query(Pid, SQL, [])
  %    mysql:query(Pid, SQL, [])
  
  % end),
  %  {atomic,{ok,[<<"MAX(ID)">>],[[MaxID]]}}=AA,
  %  io:format("Original Body2 data: ~p~n", [Body2]),  %% 输出原始数据
  %  JSONDATA=jsx:encode([{<<"maxid">>, MaxID+10000},  {<<"data">>,Body2 }]),
  
  % io:format("ABC------>     ~p~n", [AA]),
  %   Encrypted=base64:encode(JSONDATA),
  %   io:format("Original data: ~p~n", [JSONDATA]),  %% 输出原始数据
  %   io:format("Encrypted data: ~p~n", [Encrypted]),  %% 输出加密后的数据
  %   Req11 = cowboy_req:set_resp_header(<<"access-control-allow-origin">>, <<$*>>, Req),
  
  %   Req21 = cowboy_req:set_resp_header(<<"access-control-allow-methods">>, <<"POST">>, Req11),
  
  %   Req31 = cowboy_req:set_resp_header(<<"access-control-allow-headers">>, <<"content-type">>, Req21),
  %   NewReq11 = cowboy_req:set_resp_body(Encrypted, Req31),
  %   {true, NewReq11, State}.
  