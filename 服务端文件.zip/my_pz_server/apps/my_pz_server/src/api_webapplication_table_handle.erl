%% coding: utf-8
-module(api_webapplication_table_handle).

-compile(export_all).




init(Req, Opts) ->
  {cowboy_rest, Req, Opts}.

allowed_methods(Req, State) ->
  {[<<"POST">>], Req, State}.

content_types_accepted(Req, State) ->
  Handlers =
    [{<<"application/x-www-form-urlencoded">>, json_post}, %%web æ¥å£
     {<<"application/json">>, json_post},
     {<<"application/json;charset=utf-8">>, json_post}],                  %%api æ¥å£
  {Handlers, Req, State}.


json_post(Req, State) ->
  %% post解析
  {ok, A, _} = cowboy_req:read_body(Req),
  Map = jsx:decode(A, [return_maps]),
 
  Orderid = maps:get(<<"orderid">>, Map),
  Phone = maps:get(<<"phone">>, Map),
  io:format("api_webapplication_table_handle*****------>     ~p~n", [{Orderid,Phone}]),

  Result =
  try

 AA= mysql_poolboy:transaction(pool1, fun (Pid) ->


Sql3 =lists:flatten(io_lib:format("UPDATE application_table set isprocessed='1' WHERE orderid= '~s'  ",  [binary_to_list( Orderid)])),

Sql2 =lists:flatten(io_lib:format("UPDATE service_order set order_state='1' WHERE orderid= '~s'  ",  [binary_to_list( Orderid)])),

Sql =lists:flatten(io_lib:format("INSERT into Assignment(phone,orderid)VALUES( '~s', '~s')  ",  [binary_to_list( Phone),binary_to_list( Orderid)])),


              mysql:query(Pid, Sql3, []),
              mysql:query(Pid, Sql2, []),
    
             mysql:query(Pid, Sql, [])
          
          end),



          jsx:encode([{<<"code">>, 1}, {<<"msg">>, <<"error param"/utf8>>}, {<<"data">>, AA}])

    
  catch
    _:_ ->
      jsx:encode([{<<"code">>, 1}, {<<"msg">>, <<"error param"/utf8>>}, {<<"data">>, ""}])
  end,

  io:format("api_webapplication_table_handle*****------>     ~p~n", [Result]),
  NewReq11 = cowboy_req:set_resp_body(Result, Req),
  {true, NewReq11, State}.
