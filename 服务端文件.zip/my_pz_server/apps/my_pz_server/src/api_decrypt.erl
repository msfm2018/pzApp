%% coding: utf-8
-module(api_decrypt).

-compile(export_all).
% base64解码


init(Req, Opts) ->
  {cowboy_rest, Req, Opts}.

allowed_methods(Req, State) ->
  {[<<"POST">>], Req, State}.

content_types_accepted(Req, State) ->
  Handlers =
    [{<<"application/x-www-form-urlencoded">>, json_post}, %%web æ¥å£
     {<<"application/json">>, json_post},
     {<<"application/json;charset=utf-8">>, json_post}],                  %%api æ¥å£
  {Handlers, Req, State}.


json_post(Req, State) ->
  %% post解析
  {ok, A, _} = cowboy_req:read_body(Req),
  Map = jsx:decode(A, [return_maps]),
  Code = maps:get(<<"code">>, Map),
  io:format("code:::::::::::::------>     ~p~n", [Code]),


    Decrypted = base64:decode(Code),
    io:format("Original data: ~s~n", [Code]),  %% 输出原始数据
   io:format("Decrypted data: ~p~n", [Decrypted]),  %% 输出解密后的数据




  Req11 = cowboy_req:set_resp_header(<<"access-control-allow-origin">>, <<$*>>, Req),

  Req21 = cowboy_req:set_resp_header(<<"access-control-allow-methods">>, <<"POST">>, Req11),

  Req31 =
    cowboy_req:set_resp_header(<<"access-control-allow-headers">>, <<"content-type">>, Req21),
  NewReq11 = cowboy_req:set_resp_body("ok", Req31),
  {true, NewReq11, State}.
