%% coding: utf-8
-module(api_service_order_get).

-compile(export_all).


init(Req, Opts) ->
  {cowboy_rest, Req, Opts}.

allowed_methods(Req, State) ->
  {[<<"POST">>], Req, State}.

content_types_accepted(Req, State) ->
  Handlers =
    [{<<"application/x-www-form-urlencoded">>, json_post}, %%web æ¥å£
     {<<"application/json">>, json_post},
     {<<"application/json;charset=utf-8">>, json_post}],                  %%api æ¥å£
  {Handlers, Req, State}.


json_post(Req, State) ->
  %% post解析
  {ok, A, _} = cowboy_req:read_body(Req),
  Map = jsx:decode(A, [return_maps]),
  Userid = maps:get(<<"userid">>, Map),
  % io:format("Dt Name*****------>     ~p~n", [{Userid}]),
  
  Result =
    try
          Sql3 =
        lists:flatten(
          io_lib:format("SELECT c.name AS companion_name, c.phone AS companion_phone, so.*,service_info.name as servicename
          FROM companions c
           JOIN Assignment a ON c.phone = a.phone
           JOIN service_order so ON so.orderid = a.orderid
          join service_info  on service_info.id= so.serviceid
          WHERE so.userid = '~s' and so.delflag<>'-1';
           ",[integer_to_list( Userid)])),
    



          % SELECT c.name AS companion_name, c.phone AS companion_phone, so.*,service_info.name as servicename
          % FROM companions c
          %  JOIN Assignment a ON c.phone = a.phone
          %  JOIN service_order so ON so.orderid = a.orderid
          % join service_info  on service_info.id= so.serviceid
          % WHERE so.userid = '10041' and so.delflag<>'-1';
          

      io:format("sql:::::~p~n", [Sql3]),
      try
        {ok, FieldList, DataList} = mysql_poolboy:query(pool1, Sql3),
        
          case DataList of
            [] ->
              jsx:encode([{<<"code">>, -1}, {<<"msg">>, <<"no data"/utf8>>}, {<<"data">>, []}]);
            _ ->
              V = [lists:zip(FieldList, D_DATA) || D_DATA <- DataList],
              jsx:encode([{<<"code">>, 0}, {<<"msg">>, <<"succ"/utf8>>}, {<<"data">>, V}])
          end
       
      catch
        _:_ ->
          jsx:encode([{<<"code">>, -1}, {<<"msg">>, <<"error"/utf8>>}, {<<"data">>, ""}])
      end
    catch
      _:_ ->
        jsx:encode([{<<"code">>, -1}, {<<"msg">>, <<"error param"/utf8>>}, {<<"data">>, ""}])
    end,

  NewReq11 = cowboy_req:set_resp_body(Result, Req),
  {true, NewReq11, State}.
