-module(api_server_info_get).
-compile(export_all).


init(Req, Opts) ->
    {cowboy_rest, Req, Opts}.

allowed_methods(Req, State) ->
    {[<<"GET">>], Req, State}.

content_types_provided(Req, State) ->
    {[{<<"application/json">>, handle_get_info}], Req, State}.

handle_get_info(Req, State) ->
    Json = get_server_info_json(),
    {Json, Req, State}.

get_server_info_json() ->
    Sql = "select * from service_info",
    case run_query(Sql) of
        {ok, _, []} ->
            encode_json(-1, <<"no data">>, []);
        {ok, FieldList, DataList} ->
            Data = [maps:from_list(lists:zip(FieldList, Row)) || Row <- DataList],
            encode_json(0, <<"succ">>, Data);
        {error, Reason} ->
            encode_json(1, <<"error">>, [Reason])
    end.

run_query(Sql) ->
    try
        mysql_poolboy:query(pool1, Sql)
    catch
        _:Reason -> {error, Reason}
    end.

encode_json(Code, Msg, Data) ->
    json:encode(#{
        <<"code">> => Code,
        <<"msg">> => Msg,
        <<"data">> => Data
    }).
