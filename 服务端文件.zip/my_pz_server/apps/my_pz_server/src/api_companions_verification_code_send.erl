%% coding: utf-8
-module(api_companions_verification_code_send).

-compile(export_all).


init(Req, Opts) ->
  {cowboy_rest, Req, Opts}.

allowed_methods(Req, State) ->
  {[<<"POST">>], Req, State}.

content_types_accepted(Req, State) ->
  Handlers =
    [{<<"application/x-www-form-urlencoded">>, json_post}, %%web æ¥å£
     {<<"application/json">>, json_post},
     {<<"application/json;charset=utf-8">>, json_post}],                  %%api æ¥å£
  {Handlers, Req, State}.



json_post(Req, State) ->
  %% post解析
  {ok, A, _} = cowboy_req:read_body(Req),
  Map = jsx:decode(A, [return_maps]),
  Phone = maps:get(<<"phone">>, Map),
  % io:format("Phone*****------>     ~p~n", [{Phone}]),
  
  Sql =lists:flatten(io_lib:format("select phone from  companions  WHERE phone = '~s' ",  [binary_to_list( Phone)])),
  {ok, FieldList1, DataList1} = mysql_poolboy:query(pool1, Sql),
  Result =case DataList1 of
    []->
       Rnum=random:uniform(1000000),
      %  io:format("Rnum*****------>     ~p~n", [Rnum]),
    jsx:encode([{<<"code">>, 0}, {<<"msg">>, <<"succ"/utf8>>}, {<<"data">>, Rnum}]);
    % 向接口发送  
  
      % try   
      %       Sql3 = lists:flatten(
      %       io_lib:format("INSERT INTO companions (phone, vc)  SELECT '~s', '~s' FROM dual   WHERE NOT EXISTS (SELECT 1 FROM companions WHERE phone = '~s')",
      %       [ binary_to_list( Phone),integer_to_list( Rnum),binary_to_list( Phone)])),
  
        %  try  
          % AA= mysql_poolboy:query(pool1, Sql3),
       
          %   case AA of
          %     ok ->
          %       jsx:encode([{<<"code">>, 0}, {<<"msg">>, <<"no data"/utf8>>}, {<<"data">>, []}]);
          %     _ ->
              
                % jsx:encode([{<<"code">>, -1}, {<<"msg">>, <<"succ"/utf8>>}, {<<"data">>, "error"}])
            % end       
        % catch
        %   _:_ ->
        %     jsx:encode([{<<"code">>, 1}, {<<"msg">>, <<"error"/utf8>>}, {<<"data">>, ""}])
        % end
      % catch
      %   _:_ ->
      %     jsx:encode([{<<"code">>, 1}, {<<"msg">>, <<"error param"/utf8>>}, {<<"data">>, ""}])
      % end;

  _ ->
    jsx:encode([{<<"code">>, 100}, {<<"msg">>, <<"error param"/utf8>>}, {<<"data">>, "已注册"}])
end,

  % Rnum=random:uniform(1000000),
  % % 向接口发送  
  % Result =
  %   try   
  %         Sql3 = lists:flatten(
  %         io_lib:format("INSERT INTO companions (phone, pwd)  SELECT '~s', '~s' FROM dual   WHERE NOT EXISTS (SELECT 1 FROM companions WHERE phone = '~s')",
  %         [ binary_to_list( Phone),integer_to_list( Rnum),binary_to_list( Phone)])),

  %      try  
  %       AA= mysql_poolboy:query(pool1, Sql3),
  %       {ok, FieldList, DataList} =AA,
  %         case DataList of
  %           [] ->
  %             jsx:encode([{<<"code">>, -1}, {<<"msg">>, <<"no data"/utf8>>}, {<<"data">>, []}]);
  %           _ ->
  %             V = [lists:zip(FieldList, D_DATA) || D_DATA <- DataList],
  %             jsx:encode([{<<"code">>, 0}, {<<"msg">>, <<"succ"/utf8>>}, {<<"data">>, V}])
  %         end       
  %     catch
  %       _:_ ->
  %         jsx:encode([{<<"code">>, 1}, {<<"msg">>, <<"error"/utf8>>}, {<<"data">>, ""}])
  %     end
  %   catch
  %     _:_ ->
  %       jsx:encode([{<<"code">>, 1}, {<<"msg">>, <<"error param"/utf8>>}, {<<"data">>, ""}])
  %   end,  
  
  




  NewReq11 = cowboy_req:set_resp_body(Result, Req),
  {true, NewReq11, State}.
