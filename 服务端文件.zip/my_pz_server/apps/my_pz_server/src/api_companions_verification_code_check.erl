%% coding: utf-8
-module(api_companions_verification_code_check).

-compile(export_all).


init(Req, Opts) ->
  {cowboy_rest, Req, Opts}.

allowed_methods(Req, State) ->
  {[<<"POST">>], Req, State}.

content_types_accepted(Req, State) ->
  Handlers =
    [{<<"application/x-www-form-urlencoded">>, json_post}, %%web æ¥å£
     {<<"application/json">>, json_post},
     {<<"application/json;charset=utf-8">>, json_post}],                  %%api æ¥å£
  {Handlers, Req, State}.



json_post(Req, State) ->
  %% post解析
  {ok, A, _} = cowboy_req:read_body(Req),
  Map = jsx:decode(A, [return_maps]),
  Phone = maps:get(<<"phone">>, Map),
  Vc = maps:get(<<"vc">>, Map), %%验证码
  % io:format("Phone*****------>     ~p~n", [{Phone,Vc}]), 
  
  Sql =lists:flatten(io_lib:format("select phone from  companions  WHERE phone = '~s' and vc = '~s' ",  [binary_to_list( Phone),binary_to_list( Vc)])),
  {ok, FieldList1, DataList1} = mysql_poolboy:query(pool1, Sql),
  Result =case DataList1 of
    []->   
          jsx:encode([{<<"code">>, -1}, {<<"msg">>, <<"error param"/utf8>>}, {<<"data">>, ""}]);
  _ ->
    jsx:encode([{<<"code">>, 100}, {<<"msg">>, <<"error param"/utf8>>}, {<<"data">>, "已注册"}])
end,




  NewReq11 = cowboy_req:set_resp_body(Result, Req),
  {true, NewReq11, State}.
