%% coding: utf-8
-module(api_companions).

-compile(export_all).




init(Req, Opts) ->
  {cowboy_rest, Req, Opts}.

allowed_methods(Req, State) ->
  {[<<"POST">>], Req, State}.

content_types_accepted(Req, State) ->
  Handlers =
    [{<<"application/x-www-form-urlencoded">>, json_post}, %%web æ¥å£
     {<<"application/json">>, json_post},
     {<<"application/json;charset=utf-8">>, json_post}],                  %%api æ¥å£
  {Handlers, Req, State}.


json_post(Req, State) ->
  %% post解析
  {ok, A, _} = cowboy_req:read_body(Req),
  Map = jsx:decode(A, [return_maps]),
  Name = maps:get(<<"name">>, Map),
 
  Phone = maps:get(<<"phone">>, Map),
  Address = maps:get(<<"address">>, Map),
  CardId = maps:get(<<"cardId">>, Map),
  Gender = maps:get(<<"gender">>, Map),
  Qualification = maps:get(<<"qualification">>, Map),
  ExperienceYears = maps:get(<<"experienceYears">>, Map),
  Specialties = maps:get(<<"specialties">>, Map),
  ProfileText = maps:get(<<"profileText">>, Map),
  Age = maps:get(<<"age">>, Map),

  Pwd = maps:get(<<"pwd">>, Map),
  io:format("api_companions*****------>     ~p~n", [{Name,Phone,Address, CardId,Gender,Qualification,   ExperienceYears  ,Specialties,ProfileText,Pwd}]),



  Result =
    try

      %     Sql3 = lists:flatten(io_lib:format("update  companions set name='~s',phone='~s',address='~s'
      %     cardid='~s',gender='~s',qualification='~s' 
      %     experience_years='~s',specialties='~s',profile_text='~s' 
      %     pwd='~s'   
        
      %  where phone='~s'", [  binary_to_list(Name), binary_to_list(Phone),binary_to_list(Address),
      %  binary_to_list(CardId),binary_to_list(Gender),binary_to_list(Qualification),
      %  binary_to_list(ExperienceYears),binary_to_list(Specialties),binary_to_list(ProfileText),
      %  binary_to_list(Pwd),binary_to_list(Phone)])),


      % io_lib:format("insert into  service_order  (phone,name,hospital,department,gender,orderdate,other,userid,orderid,serviceid) values('~s','~s','~s','~s','~s','~s','~s','~s','~s','~s') ",
      % [Phone,Name,Hospital,Department,Gender,OrderDate,Other,integer_to_list(Userid),Orderid,Serviceid])),


       Sql3 = lists:flatten(io_lib:format("INSERT INTO companions (  name,phone,address, cardid,gender,qualification,
        experience_years,specialties,profile_text,pwd ,age)
        values('~s','~s','~s','~s','~s','~s','~s','~s','~s','~s','~s')", [  binary_to_list(Name), binary_to_list(Phone),binary_to_list(Address),
    binary_to_list(CardId),binary_to_list(Gender),binary_to_list(Qualification),
    binary_to_list(ExperienceYears),binary_to_list(Specialties),binary_to_list(ProfileText),
    binary_to_list(Pwd),binary_to_list(Age)])),


     
      % io:format("~p~n", [Sql3]),

      try
         mysql_poolboy:query(pool1, Sql3),
      

        jsx:encode([{<<"code">>, 0}, {<<"msg">>, <<"succ"/utf8>>}, {<<"data">>, ""}])
      catch
        _:_ ->
          jsx:encode([{<<"code">>, 1}, {<<"msg">>, <<"error"/utf8>>}, {<<"data">>, ""}])
      end
    catch
      _:_ ->
        jsx:encode([{<<"code">>, 1}, {<<"msg">>, <<"error param"/utf8>>}, {<<"data">>, ""}])
    end,




    % io:format("result*****------>     ~p~n", [Result]),


  NewReq11 = cowboy_req:set_resp_body(Result, Req),
  {true, NewReq11, State}.
