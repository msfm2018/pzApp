%% coding: utf-8
-module(api_service_order_application_table_myfinish).

-compile(export_all).


init(Req, Opts) ->
  {cowboy_rest, Req, Opts}.

allowed_methods(Req, State) ->
  {[<<"POST">>], Req, State}.

content_types_accepted(Req, State) ->
  Handlers =
    [{<<"application/x-www-form-urlencoded">>, json_post}, %%web æ¥å£
     {<<"application/json">>, json_post},
     {<<"application/json;charset=utf-8">>, json_post}],                  %%api æ¥å£
  {Handlers, Req, State}.


json_post(Req, State) ->
  %% post解析
  {ok, A, _} = cowboy_req:read_body(Req),
  Map = jsx:decode(A, [return_maps]),
  Phone = maps:get(<<"phone">>, Map),
  % io:format("api_service_order_del:::::Key *****------>     ~p~n", [{Orderid}]),
  
  
  
  
  Phone = maps:get(<<"phone">>, Map),
  Orderid = maps:get(<<"orderid">>, Map),

  io:format("api_service_order_application_table_myfinish*****------>     ~p~n", [{Phone,Orderid}]),
  

   Result =
  try

 AA= mysql_poolboy:transaction(pool1, fun (Pid) ->


Sql3 =lists:flatten(io_lib:format("UPDATE application_table set isprocessed='2' WHERE orderid= '~s'  ",  [binary_to_list( Orderid)])),

Sql2 =lists:flatten(io_lib:format("UPDATE service_order set order_state='2' WHERE orderid= '~s'  ",  [binary_to_list( Orderid)])),

Sql =lists:flatten(io_lib:format("UPDATE  Assignment set state ='2' where phone='~s'  and orderid= '~s'",
  [binary_to_list( Phone),binary_to_list( Orderid)])),

  io:format("api_service_order_application_table_myfinish*****------> Sql    ~p~n", [{Sql3,Sql,Sql}]),
              mysql:query(Pid, Sql3, []),
              mysql:query(Pid, Sql2, []),
    
             mysql:query(Pid, Sql, [])
          
          end),



          io:format("api_service_order_application_table_myfinish*****------>     ~p~n", [{AA}]),
          jsx:encode([{<<"code">>, 1}, {<<"msg">>, <<"error param"/utf8>>}, {<<"data">>, AA}])

    
  catch
    _:_ ->
      jsx:encode([{<<"code">>, 1}, {<<"msg">>, <<"error param"/utf8>>}, {<<"data">>, ""}])
  end,

  io:format("api_webapplication_table_handle*****------>     ~p~n", [Result]),
  NewReq11 = cowboy_req:set_resp_body(Result, Req),
  {true, NewReq11, State}.
  
  