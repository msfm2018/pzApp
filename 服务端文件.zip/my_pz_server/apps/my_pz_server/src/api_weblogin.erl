%% coding: utf-8
-module(api_weblogin).

-compile(export_all).



init(Req, Opts) ->
  {cowboy_rest, Req, Opts}.

allowed_methods(Req, State) ->
  {[<<"POST">>], Req, State}.

content_types_accepted(Req, State) ->
  Handlers =
    [{<<"application/x-www-form-urlencoded">>, json_post}, %%web æ¥å£
     {<<"application/json">>, json_post},
     {<<"application/json;charset=utf-8">>, json_post}],                  %%api æ¥å£
  {Handlers, Req, State}.




  



json_post(Req, State) ->
  %% post解析
  {ok, A, _} = cowboy_req:read_body(Req),
  Map = jsx:decode(A, [return_maps]),
  User = maps:get(<<"user">>, Map),
  Pwd = maps:get(<<"pwd">>, Map),


io:format("~p~n",[{User,Pwd}]),

  

  Result =
try

  Sql3 =
    lists:flatten(
      io_lib:format("SELECT * from webuser WHERE user='~s' and  pwd='~s' ",[binary_to_list(User),binary_to_list(Pwd)])),
      io:format("--------->~p~n",[Sql3]),

  try
    {ok, FieldList, DataList} = mysql_poolboy:query(pool1, Sql3),
    V = case DataList of
          [] ->

            jsx:encode([{<<"code">>, 0}, {<<"msg">>, <<"data"/utf8>>}, {<<"data">>, ""}]);
          _ ->
       
            jsx:encode([{<<"code">>, 2}, {<<"msg">>, <<"succ"/utf8>>}, {<<"data">>, ""}])
        end
   

   
  catch
    _:_ ->
      jsx:encode([{<<"code">>, 1}, {<<"msg">>, <<"error"/utf8>>}, {<<"data">>, ""}])
  end
catch
  _:_ ->
    jsx:encode([{<<"code">>, 1}, {<<"msg">>, <<"error param"/utf8>>}, {<<"data">>, ""}])
end,


  

    %注意：：：：：：：： 不存在 nginx的时候 这样可以跨域  存在的时候nginx配置跨域 这里去掉

    % Req11 = cowboy_req:set_resp_header(<<"access-control-allow-origin">>, <<$*>>, Req),
    % Req21 = cowboy_req:set_resp_header(<<"access-control-allow-methods">>, <<"POST">>, Req11),
    %  Req31 = cowboy_req:set_resp_header(<<"access-control-allow-headers">>, <<"content-type">>, Req21),

    NewReq11 = cowboy_req:set_resp_body(Result, Req),
    {true, NewReq11, State}.















  % json_post(Req, State) ->
  %   %% post解析
  %   {ok, A, _} = cowboy_req:read_body(Req),
  %   Map = jsx:decode(A, [return_maps]),
  %   Code = maps:get(<<"code">>, Map),
  %   io:format("Map*****------>     ~p~n", [Map]),
  
  %   Param="appid="++?Appid++"&secret="++?Secret++"&js_code=" ++ binary_to_list( Code) ++ "&grant_type=authorization_code",
  %   io:format("Param------>     ~p~n", [Param]),
  
  %   ReqHeaders = [{<<"Content-Type">>, <<"application/x-www-form-urlencoded">>}],
  %   {ok, _, _, Ref3} = hackney:request(post, <<"https://api.weixin.qq.com/sns/jscode2session">>,ReqHeaders, Param),
  %   {ok, Body2} = hackney:body(Ref3),
  
  
  
  %   AA=mysql_poolboy:transaction(pool1, fun (Pid) ->
  %     mysql:query(Pid, "insert into  unique_numbers  (number) values(?)", [1]),
  %     SQL = "SELECT MAX(ID) FROM unique_numbers",
  
  %     % {ok, Result} = mysql:query(Pid, SQL, [])
  %    mysql:query(Pid, SQL, [])
  
  % end),
  %  {atomic,{ok,[<<"MAX(ID)">>],[[MaxID]]}}=AA,
  %  io:format("Original Body2 data: ~p~n", [Body2]),  %% 输出原始数据
  %  JSONDATA=jsx:encode([{<<"maxid">>, MaxID+10000},  {<<"data">>,Body2 }]),
  
  % io:format("ABC------>     ~p~n", [AA]),
  %   Encrypted=base64:encode(JSONDATA),
  %   io:format("Original data: ~p~n", [JSONDATA]),  %% 输出原始数据
  %   io:format("Encrypted data: ~p~n", [Encrypted]),  %% 输出加密后的数据
  %   Req11 = cowboy_req:set_resp_header(<<"access-control-allow-origin">>, <<$*>>, Req),
  
  %   Req21 = cowboy_req:set_resp_header(<<"access-control-allow-methods">>, <<"POST">>, Req11),
  
  %   Req31 = cowboy_req:set_resp_header(<<"access-control-allow-headers">>, <<"content-type">>, Req21),
  %   NewReq11 = cowboy_req:set_resp_body(Encrypted, Req31),
  %   {true, NewReq11, State}.
  