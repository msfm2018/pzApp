-module(token).
-compile(export_all).
%%格式 token.Timestamp
str_value(User_id) ->
  Timestamp = integer_to_list(timestamp()),
  New_id = binary_to_list(User_id) ++ Timestamp,
%%  io:format("New_id      ~p~n", [New_id]),

%%  V = uuid:to_string(uuid:uuid3(nil, binary_to_list(User_id))),
  V= uuid:to_string(uuid:uuid3(nil, New_id))++ "." ++ Timestamp,
%%  io:format("V1      ~p~n", [V1]),
%%  V = V1 ++ "." ++ Timestamp,
%%  io:format("V      ~p~n", [V]),
  replvar(V, "-", "").


%%串替换函数
replvar(S, _Var, undefined) ->
  S;
replvar(S, Var, Val) ->
  re:replace(S, Var, Val, [global, {return, list}]).


%%start(Type) ->
%%  Topic = replvar(Type, "_", "-"),
%%  io:format("topic is a: ~p~n", [Topic]).



timestamp() ->
  DateTime = calendar:universal_time(), %%必须是UTC世界时间
  calendar:datetime_to_gregorian_seconds(DateTime) - calendar:datetime_to_gregorian_seconds({{1970, 1, 1}, {0, 0, 0}}).

%%
%%F = fun(L) ->
%%Fun1 = fun
%%(_,[Args|[]],Re) ->
%%lists:reverse([Args|Re]);
%%(Self,[Args|T],Re) ->
%%Self(Self,T,[",",Args|Re])
%%end,
%%binary_to_list(list_to_binary(Fun1(Fun1,L,[])))
%%end
%%
%%F(["1","2","3"]).

