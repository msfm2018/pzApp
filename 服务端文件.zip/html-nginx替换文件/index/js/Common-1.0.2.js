var globelObject = {
	WorkLocation: '',
	UserInfo: {},
	MachineCode: 'eqweqwe',
	RandomCode: '',
	LoginType: '4'
};

//---新闻相关的
var globelParam = {
	corp_tn: 'c1',
	tb_code:'8888',
	type_code: '999',
	page_size: 10,
};


var serverUrl='http://127.0.0.1:9091'

var lastsearchkeyword='';

var needinitconfig=0;

axios.defaults.baseURL = serverUrl;
//axios.defaults.headers.post['Content-Type'] = 'application/x-www-form-urlencoded';
// `transformRequest` 允许在向服务器发送前，修改请求数据
// 只能用在 'PUT', 'POST' 和 'PATCH' 这几个请求方法
// 后面数组中的函数必须返回一个字符串，或 ArrayBuffer，或 Stream
axios.defaults.transformRequest = function(data, headers) {
	// 对 data 进行任意转换处理
	return data;
};
// `paramsSerializer` 是一个负责 `params` 序列化的函数
// (e.g. https://www.npmjs.com/package/qs, http://api.jquery.com/jquery.param/)
axios.defaults.paramsSerializer = function(params) {
	return Qs.stringify(params, {
		arrayFormat: 'brackets'
	})
};
// `transformResponse` 在传递给 then/catch 前，允许修改响应数据
axios.defaults.transformResponse = function(data) {
	// 对 data 进行任意转换处理
	return data;
};

//统一的请求
function PostData(url, param)
{
	console.log('2222222222222222222222222'+serverUrl+"/" + url );
	  return new Promise((resolve, reject) =>
	   {
		axios.post(serverUrl+"/" + url , param)
		.then(function(response) 
		{
			
			// resolve(response.data);
			 
			var returnJsonStr = GetResponseData(response.data);
			if(response.data)
			{
				resolve(returnJsonStr);

			}
			else
			{
			   resolve(response.data);
			}

		})
		.catch(function(err){
			//失败回调
			reject(err);
	
		});
    });

}

function validate_required(field,alerttxt)
{
with (field)
  {
  if (alerttxt==null||alerttxt=="")
    {alert(alerttxt);return false}
  else {return true}
  }
}

function isnull(val) 
{
 
    if(val == undefined || val == null)
    {
    	return true;
    }
    else
    {
		var str = val.replace(/(^\s*)|(\s*$)/g, '');//去除空格;
	 
	    if (str == '' || str == undefined || str == null) {
	            return true;
	            
	     } else {
	            return false;
	            
		 }
	 }
}

//格式化日期
function dateFormat(thisDate, fmt) {
    var o = {
        "M+": thisDate.getMonth() + 1,
        "d+": thisDate.getDate(),
        "h+": thisDate.getHours(),
        "m+": thisDate.getMinutes(),
        "s+": thisDate.getSeconds(),
        "q+": Math.floor((thisDate.getMonth() + 3) / 3),
        "S": thisDate.getMilliseconds()
    };
    if (/(y+)/.test(fmt))
        fmt = fmt.replace(RegExp.$1, (thisDate.getFullYear() + "").substr(4 - RegExp.$1.length));
    for (var k in o)
        if (new RegExp("(" + k + ")").test(fmt))
            fmt = fmt.replace(RegExp.$1, (RegExp.$1.length == 1) ? (o[k]) : (("00" + o[k]).substr(("" + o[k]).length)));
    return fmt;
}

function getdatastr()
{
   var Datest=new Date();
   return dateFormat(Datest, "yyyy-MM-dd hh:mm:ss");
}

function gettimestamp()
{
	return new Date().getTime();
}

function checkPhone(v) 
{
        if (!(/^1(3|4|5|6|7|8)\d{9}$/.test(v))) {
             return true;
        } else {
             return false;
        }
}

function checkMail(v) 
{
        var reg = /^\w+((.\w+)|(-\w+))@[A-Za-z0-9]+((.|-)[A-Za-z0-9]+).[A-Za-z0-9]+$/; //正则表达式
        if (!reg.test(v)) { //正则验证不通过，格式不对
             return true;
        } else {
             return false;
        }
}

function clearmsginfo()
{
	//$("#imgtalk").attr("value","值");
	$("#edit-submitted-company-name").attr("value","");
	$("#edit-submitted-name").attr("value","");
	$("#edit-submitted-email").attr("value","");
	$("#edit-submitted-telphone").attr("value","");
    $("#edit-submitted-question").attr("value","");
}

//------搜索----
//博文详情
function QueryBlogDetail_Action()
{

QueryBlogDetail('8088d3ef-3fe6-4c1b-b1c6-77f8b28c54ca')
.then(function(response)
{ 
	console.log('博文response='+response); 
	if (response != null) 
	{   var json = JSON.parse(response);
		if (json.State == false)
		{ alert(decodeMessage(json.Message));}
		else
		{
		TotalPages=json.TotalPages;

		}
	}
}
)
.catch(function(err)
{
   console.log('博文err='+err); 
});

}


function QueryBlogDetail(artid) {
	
	var paramstr = artid;//JSON.stringify(initParam);
	
    return new Promise((resolve, reject) => 
     {

 	   PostData('ArticleDetailNew',paramstr)
 	   .then(function(response)
 	   { 
 		resolve(response)
 	   })
 	   .catch(function(err)
 	   {
 		reject(err)
 	   })
 	});
}


//第六部分----博文接口--有分页
function QueryBasePageListBlog_Action()
{

QueryBasePageListBlog('',1)
.then(function(response)
{ 
	console.log('博文response='+response); 
	if (response != null) 
	{   var json = JSON.parse(response);
		if (json.State == false)
		{ alert(decodeMessage(json.Message));}
		else
		{
		TotalPages=json.TotalPages;

		}
	}
}
)
.catch(function(err)
{
   console.log('博文err='+err); 
});

}



/**提示框
		 * @param {string} con：提示信息
		 * @param {boolean} sx：是否需要刷新页面
		 */
function promptBox(con, sx = false) {
	var db = document;
	var w = window;
	if (w.parent != undefined) {
		db = w.parent.document;
	}
	var box = document.createElement("div");
	db.body.appendChild(box);
	box.style = "position: fixed;left:0;right:0;top:0;bottom:0;z-index:200;";
	var div = document.createElement("div");
	box.appendChild(div);
	div.style =
		"width:300px;height:100px;padding:10px;border-radius:5px;background-color: #fff;box-shadow: 2px 0 2px #666 , -2px 0 2px #666,0 2px 2px #666,0 -2px 2px #666;position: absolute;top:50%;margin-top:-100px;left:50%;margin-left:-150px;";
	var h2 = document.createElement("h2");
	h2.innerHTML = "提示信息";
	h2.style = "line-height:40px;height:40px;font-size:20px;text-align:center;border-bottom:1px solid #ccc;margin:0;";
	div.appendChild(h2);
	var condiv = document.createElement("div");
	condiv.innerHTML = con;
	condiv.style =
		"line-height:24px;font-size:16px;border-bottom:1px solid #ccc;text-indent: 2rem;padding:5px;height:26px;";
	div.appendChild(condiv);
	var btn = document.createElement("div");
	div.appendChild(btn);
	btn.style = "text-align:right;padding:5px;height:45px;";
	btn.innerHTML = `<button>确定</button>`;
	var qd = btn.children[0];
	qd.onclick = function () {		
		db.body.removeChild(box);
		if (sx) {
			w.location.reload();
		}
	}
}
function checkPhone(mobile) {
	var re = /^1[3,4,5,6,7,8,9][0-9]{9}$/;
	var result = re.test(mobile);
	if (!result) {
	  return false; //若手机号码格式不正确则返回false
	}
	return true;
  };

function customInfo() {
	const phoneNumberInput = document.querySelector('.sjh-form-input-tel');
	const phoneNumber = phoneNumberInput.value;

	const	hispitaltag = document.querySelector('.hispitaltag');
	const hospital = hispitaltag.value.trim();

	const nicknameInput = document.querySelector('.nickname-flag');
	const nickname = nicknameInput.value.trim();
if (nickname.length==0)
{

} else

if(checkPhone(phoneNumber)){


	var initParam = {
		nickname: nickname,
		phone: phoneNumber,
		h:hospital

	};
	var paramstr = JSON.stringify(initParam);
console.log(paramstr);

    return new Promise((resolve, reject) => 
     {

 	   PostData('webapp_customInfo',paramstr)
 	   .then(function(response)
 	   { 
		let jsonObject = JSON.parse(response);  

		if(jsonObject.code==0){
			phoneNumberInput.value="";
			nicknameInput.value="";
			promptBox('已提交,如紧急直接联系工作人员电话。')
	// alert('已提交,请耐心等待。')

			// showSuccessAlert();
		}
 		resolve(response)
 	   })
 	   .catch(function(err)
 	   {
 		reject(err)
 	   })
 	});
} else{
	promptBox('正确填写手机号！')
}
}




function QueryArticlePageList_Code(kindcode,pagecurrent) {
	//默认参数值

	var initParam = {
		corp_tn: globelParam.corp_tn,
		tb_code: globelParam.tb_code,
		type_code: globelParam.type_code,
		kind_code: kindcode,//'00101',
		page_size: globelParam.page_size,//10
		page_current:pagecurrent,//page_current1,
	};
	var paramstr = JSON.stringify(initParam);
    return new Promise((resolve, reject) => 
     {

 	   PostData('ArticlePageList_RightLikeByKind',paramstr)
 	   .then(function(response)
 	   { 
 		resolve(response)
 	   })
 	   .catch(function(err)
 	   {
 		reject(err)
 	   })
 	});
}



//请求获取新闻详情
function QueryArticleDetail(artid) {
	//默认参数值

	var initParam = {
		corp_tn: globelParam.corp_tn,
		art_id: artid,

	};
	var paramstr = JSON.stringify(initParam);
    return new Promise((resolve, reject) => 
     {

 	   PostData('ArticleDetail',paramstr)
 	   .then(function(response)
 	   { 
 		resolve(response)
 	   })
 	   .catch(function(err)
 	   {
 		reject(err)
 	   })
 	});
}





function GetResponseData(responseText) {
	var returnJsonStr = responseText
		.replace("<string xmlns=\"http://schemas.microsoft.com/2003/10/Serialization/\">", "")
		.replace("</string>", "");
	return returnJsonStr;
}


String.prototype.replaceAll = function(FindText, RepText) {
	regExp = new RegExp(FindText, "g");
	return this.replace(regExp, RepText);
}

function Post(url, param, successfun) {
	var xhr = new plus.net.XMLHttpRequest();
	xhr.onreadystatechange = function() {
		console.log("onreadystatechange: " + xhr.readyState);
	}
	xhr.onload = function(e) {
		console.log(xhr.responseText)
		// xhr请求成功事件处理
		var returnJsonStr = GetResponseData(xhr.responseText);
		var json = JSON.parse(decodeURIComponent(Base64.decode(returnJsonStr)));
		successfun(json);
	};
	xhr.onerror = function(e) {
		var str = "lengthComputable=" + e.lengthComputable + "loaded=" + e.loaded + ";total=" + e.total;
		console.log("onerror: " + str);
	}
	var base64str = Base64.encode(encodeURIComponent(JSON.stringify(param)));
	xhr.open("POST", "http://218.246.23.195:1889" + "/" + url + "/" + base64str.length);
	xhr.setRequestHeader('Content-Type', 'text/html');
	// 发送HTTP请求
	console.log(base64str)
	console.log(base64str.length)
	xhr.send(base64str);
}




//打开新页面
function OpenPage(url) {
	try {
		plus.webview.open(url);
	} catch {
		window.location.href = url;
	}
}

//post请求
function axiosPost(url, param, successfun) {
	//默认参数值
	var initParam = {
		MachineCode: globelObject.MachineCode,
		RandomCode: globelObject.RandomCode,
		LoginType: '4',
		outStr: "r_result,r_error,r_cursor",
		inJson: {

		}
	};
	initParam.procName = param.procName;
	for (var item in param) {
		if (item != "inJson") {
			initParam[item] = param[item];
		}
	}
	for (var item in param.inJson) {
		if (typeof(param[item]) != "number" && typeof(param[item]) != "boolean") {
			initParam.inJson[item] = Base64.encode(encodeURIComponent(param.inJson[item]));
		}
	}

	var base64str = Base64.encode(encodeURIComponent(JSON.stringify(initParam)));
	console.log(base64str);
	axios.post("/" + url + "/" + base64str.length, base64str)
		.then(function(response) {
			if (response.data != null) {
				var returnJsonStr = GetResponseData(response.data);
				var json = JSON.parse(decodeURIComponent(Base64.decode(returnJsonStr)));
				successfun(json);
			}
		});
}

function decodeObject(obje) //对实体字段解码
{
	for (var item in obje) {
		try {
			if (typeof(obje[item]) != "number" && typeof(obje[item]) != "boolean") {
				obje[item] = decodeMessage(obje[item]);
			}
		} catch {

		}
	}

	return obje;
}


function decodeMessage(message) {
	return decodeURIComponent(Base64.decode(message)).replaceAll("\\+", "")
}

function encodeMessage(message) {
	return Base64.encode(encodeURIComponent(message)).replaceAll("\\+", "")
}



// //获取查询参数
// function getQueryVariable(variable) {
// 	var query = window.location.search.substring(1);
// 	var vars = query.split("&");
// 	for (var i = 0; i < vars.length; i++) {
// 		var pair = vars[i].split("=");
// 		if (pair[0] == variable) {
// 			return pair[1];
// 		}
// 	}
// 	return (false);
// }

function getParentQueryVariable(variable) {
	var query = parent.location.search.substring(1);
	var vars = query.split("&");
	for (var i = 0; i < vars.length; i++) {
		var pair = vars[i].split("=");
		if (pair[0] == variable) {
			return pair[1];
		}
	}
	return (false);
}


function GetGuid() {
	return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
		var r = Math.random() * 16 | 0,
			v = c == 'x' ? r : (r & 0x3 | 0x8);
		return v.toString(16);
	});
}


function getCurrentUrl()
{
	var url = "";  
        try {  
            url = window.top.document.referrer  
        } catch(M) {  
            if (window.parent) {  
                try {  
                    url = window.parent.document.referrer  
                } catch(L) {  
                    url = ""  
                }  
            }  
        }  
        if (url === "") {  
            url = document.referrer  
        }  
        return url
}
//时间中的天2012-11-12->12
function gettimedayinfo(val) 
{

let time = val;
let timearr = time.replace(" ", ":").replace(/\:/g, "-").split("-");//["2012", "12", "12", "00", "00", "00"]
let timestr = timearr[2];// 2012-12-12
return timestr;
}

//获取当前时间
function getCurrentDateTime() {
	var day = new Date();
	return day.format("yyyy-MM-dd hh:mm:ss");
}

/**
 *对Date的扩展，将 Date 转化为指定格式的String
 *月(M)、日(d)、小时(h)、分(m)、秒(s)、季度(q) 可以用 1-2 个占位符，
 *年(y)可以用 1-4 个占位符，毫秒(S)只能用 1 个占位符(是 1-3 位的数字)
 *例子：
 *(new Date()).Format("yyyy-MM-dd hh:mm:ss.S") ==> 2006-07-02 08:09:04.423
 *(new Date()).Format("yyyy-M-d h:m:s.S")      ==> 2006-7-2 8:9:4.18
 */
Date.prototype.format = function(fmt) {
	var o = {
		"M+": this.getMonth() + 1, //月份
		"d+": this.getDate(), //日
		"h+": this.getHours(), //小时
		"m+": this.getMinutes(), //分
		"s+": this.getSeconds(), //秒
		"q+": Math.floor((this.getMonth() + 3) / 3), //季度
		"S": this.getMilliseconds() //毫秒
	};
	if (/(y+)/.test(fmt)) fmt = fmt.replace(RegExp.$1, (this.getFullYear() + "").substr(4 - RegExp.$1.length));
	for (var k in o)
		if (new RegExp("(" + k + ")").test(fmt)) fmt = fmt.replace(RegExp.$1, (RegExp.$1.length == 1) ? (o[k]) : (("00" + o[
			k]).substr(("" + o[k]).length)));
	return fmt;
}
